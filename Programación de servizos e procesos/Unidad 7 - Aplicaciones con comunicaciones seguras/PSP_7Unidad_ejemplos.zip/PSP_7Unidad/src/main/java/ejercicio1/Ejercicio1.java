/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

/**
 *
 * @author Juan Morillo Fernandez
 */
/*

Enunciado:
Generación de claves
Creaciónde de una clave con el algoritmo DES, y usarlo para cifrar y descifrar un mensaje
*/

public class Ejercicio1 {
    
    public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException{
    
        //Generardor de claves
        //********************
        
        System.out.println("Obteniendo generador de claves con cifrado DES");
        KeyGenerator keygen = KeyGenerator.getInstance("DES");
        //Generando clave opaca
        SecretKey key = keygen.generateKey();
        SecretKeyFactory keyfac = SecretKeyFactory.getInstance("DES");
        //Generarando clave transparente
        KeySpec keyspec = keyfac.getKeySpec(key, DESKeySpec.class);
        
        //Uso de la clase Cipher
        //**********************
        
        //Obteniendo objeto Cipher con cifrado DES
        Cipher desCipher= Cipher.getInstance("DES");
        
        //Configurar el cipher
        desCipher.init(Cipher.ENCRYPT_MODE, key);
        
        String mensaje = "Mensaje de prueba";
        System.out.println("Mensaje original:"+ mensaje);
        
        //DoFinal necesita array de bytes
        String mensajeCifrado = new String (desCipher.doFinal(mensaje.getBytes("ISO-8859-1")),"ISO-8859-1");
        
        System.out.println("Mensaje cifrado:"+ mensajeCifrado);

        
        desCipher.init(Cipher.DECRYPT_MODE,key);
        String mensajedesCifrado = new String (desCipher.doFinal(mensajeCifrado.getBytes("ISO-8859-1")),"ISO-8859-1");
        System.out.println("Mensaje descifrado:"+ mensajedesCifrado);

        //Ojo usar misma codificación en ambas acciones con el doFinal y al crear el array de bytes
    
    }
}
