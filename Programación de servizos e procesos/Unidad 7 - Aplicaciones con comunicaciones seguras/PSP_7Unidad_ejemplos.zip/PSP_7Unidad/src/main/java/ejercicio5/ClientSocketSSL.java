/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio5;

/**
 *
 * @author Juan Morillo Fernandez
 */
/*
El cliente falla porque necesitamos certificados.
Hay que crearlos con la herramienta keytool por ejemplo
Y agregarlos al cliente y servidor
System.setProperty("javax.net.ssl.keyStore", "AlmacenSSL");
System.setProperty("javax.net.ssl.keyStorePassword", "1234567");
y en el programa cliente:
System.setProperty("javax.net.ssl.trustStore", "UsuarioAlmacenSSL"); 
System.setProperty("javax.net.ssl.trustStorePassword", "7654321");

Lo que me interesa es que sepáis que existe la posibilidad de crear 
sockets seguros

*/

import java.io.*;
import java.net.*;
import javax.net.ssl.*;

public class ClientSocketSSL {

  private static final String HOST = "localhost";

  private static final int PORT = 9096;

  public static void main(String[] args) throws Exception {
    
    SSLSocketFactory sf = (SSLSocketFactory) SSLSocketFactory.getDefault();
    Socket s = sf.createSocket(HOST, PORT);
    OutputStream out = s.getOutputStream();
    out.write("\nConnection established.\n\n".getBytes());
    out.flush();
    int theCharacter = 0;
    theCharacter = System.in.read();
    while (theCharacter != '/') 
    {
      out.write(theCharacter);
      out.flush();
      theCharacter = System.in.read();
    }

    out.close();
    s.close();
  }
}
