/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3;

import java.io.IOException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import javax.crypto.Cipher;
/*
Enunciado: 
nos piden simular un cifrado asimetrico con el algoritmo RSA.

Dialogo de cifrado con clave pública:
El esquema es el siguiente:
• El participante A crea una clave de encriptación simétrica (clave secreta). La utiliza para encriptar sus mensajes de texto.
• El participante A encripta la clave simétrica (secreta) con la clave pública del participante B.
• El participante A envía al participante B tanto la clave simétrica encriptada como el mensaje de
texto encriptado.
• El participante B utiliza su clave privada (sólo él la tiene) para desencriptar la clave simétrica
(secreta) de A.
• El participante B utiliza la clave simétrica desencriptada para desencriptar el mensaje.


*/

/**
 *
 * @author Juan Morillo Fernandez
 */
public class Ejercicio3 {
    
    public static void main(String[] args) throws Exception {

        System.out.println("Crear clave pública y privada");
        //Creación y obtención del par de claves
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(512);//tamaño de la clave
        KeyPair clavesRSA = keyGen.generateKeyPair();

        //Clave privada

        PrivateKey clavePrivada = clavesRSA.getPrivate();

        //Clave pública
        PublicKey clavePublica = clavesRSA.getPublic();

        //Se pueden mostrar las claves para ver cuáles son, aunque esto no es aconsejable
        System.out.println("clavePublica: " + clavePublica);
        System.out.println("clavePrivada: " + clavePrivada);

        //Texto plano
        byte[] bufferClaro = "Este es el mensaje secreto\n".getBytes();

        //Ciframos con clave pública el texto plano utilizando RSA
        Cipher cifrador = Cipher.getInstance("RSA");
        cifrador.init(Cipher.ENCRYPT_MODE, clavePublica);
        System.out.println("Cifrar con clave pública el Texto:");
        mostrarBytes(bufferClaro);

        //Realización del cifrado del texto plano
        byte[] bufferCifrado = cifrador.doFinal(bufferClaro);
        System.out.println("Texto CIFRADO");
        mostrarBytes(bufferCifrado);
        System.out.println("\n_______________________________");

        //Desencriptación utilizando la clave privada
        cifrador.init(Cipher.DECRYPT_MODE, clavePrivada);
        System.out.println("Descifrar con clave privada");

        //Obtener y mostrar texto descifrado
        bufferClaro = cifrador.doFinal(bufferCifrado);
        System.out.println("Texto DESCIFRADO");
        mostrarBytes(bufferClaro);
        System.out.println("\n_______________________________");
}

public static void mostrarBytes(byte[] buffer) throws IOException {
    System.out.write(buffer);
}

}
