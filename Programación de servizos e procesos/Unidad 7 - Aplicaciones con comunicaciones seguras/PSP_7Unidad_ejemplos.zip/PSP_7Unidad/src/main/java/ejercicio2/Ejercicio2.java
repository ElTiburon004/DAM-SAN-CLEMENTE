/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2;

/**
 *
 * @author Juan Morillo Fernandez
 */
public class Ejercicio2 {
  

    public static void main(String[] args) {

        Seguridad sec = new Seguridad();

        sec.addKey("Bolivia");
        System.out.println( "Hola Mundo" );

        System.out.println( " ------------ Encriptado ------------ " );
        String texto = sec.encriptar("Hola Mundo");
        System.out.println( texto );

        System.out.println( " ------------ Desencriptado ------------ " );
        System.out.println( sec.desencriptar( texto ) );        
    }
}
  

