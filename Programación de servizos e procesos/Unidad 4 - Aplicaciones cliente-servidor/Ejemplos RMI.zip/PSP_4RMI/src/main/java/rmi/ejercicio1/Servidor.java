/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rmi.ejercicio1;

import java.rmi.AlreadyBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author Juan Morillo Fernandez
 */
public class Servidor implements RMICalc {
    
    private static final int PUERTO = 1100; //Si cambias aquí el puerto, recuerda cambiarlo en el cliente
   
            @Override
            public float sumar(float numero1, float numero2) throws RemoteException {
                return numero1 + numero2;
            };

            @Override
            public float restar(float numero1, float numero2) throws RemoteException {
                return numero1 - numero2;
            };

            @Override
            public float multiplicar(float numero1, float numero2) throws RemoteException {
                return numero1 * numero2;
            };

            @Override
            public float dividir(float numero1, float numero2) throws RemoteException {
                return numero1 / numero2;
            };
        
         public static void main(String[] args) throws RemoteException, AlreadyBoundException {
         
             //primer paso registrar el recurso
             Registry registry = LocateRegistry.createRegistry(PUERTO);
             System.out.println("Servidor escuchando en el puerto " + String.valueOf(PUERTO));
             Servidor server = new Servidor();
             
             //incribir el objeto remoto, nombre único
             registry.rebind("Calculadora", UnicastRemoteObject.exportObject(server, PUERTO));
             
         }
        	
 }

    

