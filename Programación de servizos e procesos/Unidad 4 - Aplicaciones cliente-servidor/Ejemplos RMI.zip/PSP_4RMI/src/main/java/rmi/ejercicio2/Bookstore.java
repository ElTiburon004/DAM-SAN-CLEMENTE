/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rmi.ejercicio2;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author Juan Morillo Fernandez
 */
public class Bookstore implements RMIInterface {

    private static final long serialVersionUID = 1L;
    private List<Book> bookList;

    protected Bookstore(List<Book> list) throws RemoteException {
        super();
        this.bookList = list;
    }

    
    @Override
    public Book findBook(Book book) throws RemoteException {
        
        Iterator i = bookList.iterator();
        while (i.hasNext()){
            Book libro = (Book) i.next();
            if (libro.getIsbn().equals(book.getIsbn())){
                return libro;
            }
        }
       return null;
    }

    @Override
    public List<Book> allBooks() throws RemoteException {
        return bookList;
    }

    //metodo estatico que inicializa la lista de objetos
    private static List<Book> initializeList() {
        List<Book> list = new ArrayList<>();
        list.add(new Book("Head First Java, 2nd Edition", "978-0596009205", 31.41));
        list.add(new Book("Java In A Nutshell", "978-0596007737", 10.90));
        list.add(new Book("Java: The Complete Reference", "978-0071808552", 40.18));
        list.add(new Book("Head First Servlets and JSP", "978-0596516680", 35.41));
        list.add(new Book("Java Puzzlers: Traps, Pitfalls, and Corner Cases", "978-0321336781", 39.99));
        return list;
    }

    public static void main(String[] args) {
        try {

            Registry rgsty = LocateRegistry.createRegistry(1888);
            Bookstore tienda = new Bookstore(initializeList());
            rgsty.rebind("Bookstore", UnicastRemoteObject.exportObject(tienda, 1888));

            System.err.println("Server ready");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.getMessage());
        }
    }

}

