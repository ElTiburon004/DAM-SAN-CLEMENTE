/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.extra;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Calendar;

class MiHilo extends Thread{
 
    Socket s;
 
    public MiHilo(Socket s) {
        this.s=s;
    }
 
    public void run() {
 
        try( BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()))){
            Calendar c=Calendar.getInstance();
            System.out.println("se realizó la conexión con cliente de ip "+ s.getInetAddress() 
                    +" y puerto " +s.getPort());
            System.out.println("Hora de conexión: "+Calendar.getInstance().getTime());
            System.out.println("Confirmo que el cliente me envió la frase: " + br.readLine());
            System.out.println("FIN DE CONEXIÓN----------------------\n\n");
            s.close();
        } catch (IOException ex) {
            ex.printStackTrace();
 }
 }
}
