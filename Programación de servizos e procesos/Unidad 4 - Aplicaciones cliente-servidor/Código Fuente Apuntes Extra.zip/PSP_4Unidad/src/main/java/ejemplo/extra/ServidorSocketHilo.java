/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.extra;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author Juan Morillo Fernandez
 */
public class ServidorSocketHilo {
 
    public static void main(String[] args) throws IOException {
 
        try( ServerSocket ss= new ServerSocket(6000)){
            while(true){
            Socket s=ss.accept();
            new MiHilo(s).start();
 }
 }
 }
}
