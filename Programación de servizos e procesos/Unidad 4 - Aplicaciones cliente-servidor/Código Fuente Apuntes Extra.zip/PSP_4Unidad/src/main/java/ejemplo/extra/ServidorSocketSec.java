/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.extra;

/**
 *
 * @author Juan Morillo Fernandez
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Calendar;
public class ServidorSocketSec {
 
    public static void main(String[] args) throws IOException {

        try( ServerSocket ss= new ServerSocket(6000)){
            while(true){
                try(Socket s=ss.accept();
                    BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()))){
                    Calendar c=Calendar.getInstance();

                    System.out.println("se realizó la conexión con cliente de ip "+ s.getInetAddress() +" y puerto "+s.getPort());
                    System.out.println("Hora de conexión: "+Calendar.getInstance().getTime());
                    System.out.println("Confirmo que el cliente me envió la frase: " + br.readLine());
                    System.out.println("FIN DE CONEXIÓN----------------------\n\n");
        }
        }
        }
        /* 
        Otra posibilidad es ir creando varios sockets con un for, las iteraciones
            seran por posibles clientes que va a poder atender
        Modificación --> Tarea
        
        
        */

 }
}