/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.apuntes;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 *
 * @author jmor
 */
public class HiloServidor extends Thread{
    
    BufferedReader fentrada;
    PrintWriter fsalida;
    Socket socket = null;
    
    public HiloServidor(Socket s){
    
        socket = s;
        try {
        
            fsalida = new PrintWriter(socket.getOutputStream(),true); //el buffer se vacia
            fentrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            
        }catch(IOException e){
            System.out.println("Excepción de entrada y salida");
        }
        
    }
    
    public void run(){ //tarea a realizar con el cliente
    
        String cadena = "";
        try{
        while(!cadena.trim().equals("*")){
            System.out.println("Comunico con: " +socket.toString());
            cadena = fentrada.readLine();
            fsalida.println(cadena.trim().toUpperCase());
            
        }
        System.out.println("Fin con: " + socket.toString());
        fentrada.close();
        fsalida.close();
        socket.close();
        }catch(IOException e){
            System.out.println("Excepción de entrada y salida");
        }
    
        
    }
}
