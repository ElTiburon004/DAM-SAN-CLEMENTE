/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.extra;

/**
 *
 * @author Juan Morillo Fernandez
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
public class ClienteSocketA {
 public static void main(String[] args) throws IOException, InterruptedException {
    try (Socket s = new Socket("127.0.0.1", 6000);

        PrintWriter pw = new PrintWriter(s.getOutputStream(),true)){
        Thread.sleep(10000);
        pw.println("hola server soy cliente A");

 }
 }
}