/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.unidad4;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

/**
 *
 * @author Juan Morillo Fernandez
 */
public class Cliente {
    public static void main(String[] args) throws Exception {
		String Host = "localhost";
		int Puerto = 2000;//puerto remoto
		try{
			System.out.println("PROGRAMA CLIENTE INICIADO .... ");
                        //CONSTRUCTOR QUE ACEPTA HOST
			Socket Cliente = new Socket(Host, Puerto);
			
			//CREO FLUJO DE SALIDA AL SERVIDOR
			DataOutputStream flujoSalida = new DataOutputStream(Cliente.getOutputStream());
			
			//ENVIO UN SALUDO AL SERVIDOR
			flujoSalida.writeUTF("Saludos al SERVIDOR DESDE EL CLIENTE");
			
			//CREO FLUJO DE ENTRADA AL SERVIDOR
			DataInputStream flujoEntrada = new DataInputStream(Cliente.getInputStream());
			
			//EL SERVIDOR ME ENVIA UN MENSAJE
			System.out.println("Recibiendo del SERVIDOR: \n\t"+flujoEntrada.readUTF());
			
			//CERRAR STREAMS y SOCKETS
			flujoEntrada.close();
			flujoSalida.close();
			Cliente.close();
		}catch (IOException e) {
			e.printStackTrace();
		}
	}// main
}
