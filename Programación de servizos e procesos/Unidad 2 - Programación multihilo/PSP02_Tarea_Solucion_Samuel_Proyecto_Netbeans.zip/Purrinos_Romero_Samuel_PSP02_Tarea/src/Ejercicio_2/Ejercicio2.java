/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio_2;


/**
 *
 * @author samuel
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PruebaHilos hilo1= new PruebaHilos();
        PruebaHilos hilo2= new PruebaHilos();
        PruebaHilos hilo3= new PruebaHilos();
        
        hilo1.start();
        hilo2.start();
        hilo3.start();
    }
    
}

class PruebaHilos extends Thread {
    int tiempoDormido;
    PruebaHilos(){
       tiempoDormido = ((int) (Math.random() * 10000));
    }
    
    public void run(){
        try {
            System.out.println("El hilo " + getName() + " va estar dormido "+ tiempoDormido+ " milisegundos");
            sleep(tiempoDormido);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        System.out.println("El hilo "+ getName()+ "ha despertado");
    }
}
