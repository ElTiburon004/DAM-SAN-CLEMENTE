/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio_3;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author samuel
 */
public class MainEj3NoSincro {
	public static void main(String args[]) {
		try {
                    Listado lista = new Listado();
                    //Creo los objeto hilo
                    Thread primero = new Ej3NoSincro(lista);
                    Thread segundo = new Ej3NoSincro(lista);
                    
                    //Los lanzo
                    primero.start();
                    primero.join();
                    segundo.start();
                    
                    try {
                        Thread.sleep(4000);
                    } catch (InterruptedException ex) {
                        System.out.printf("Interrupcion");
                    }
                    System.out.println("\nYa termine.");
                } catch (InterruptedException ex) {
			Logger.getLogger(MainEj3NoSincro.class.getName()).log(Level.SEVERE, null, ex);
		}
		}
	}

class Ej3NoSincro extends Thread {
	Listado salida;

	//constructor
	Ej3NoSincro(Listado sali) {
		salida=sali;
        }
	public void run() {
		salida.Mostrar();
	}
}
class Listado {
	public void Mostrar() {
		System.out.println("\nEsta es mi salida ");
		for (int i=0; i<8; i++) {
			System.out.print(i+" ");
		}
	}
}
