/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio_4;

import java.util.concurrent.locks.ReentrantLock;

/**
 *
 * @author samuel
 */
public class MainCajero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        Cajero caj = new Cajero("Alameda");
        Terminal t1=new Terminal(caj, "Terminal 1");
        Terminal t2=new Terminal(caj, "Terminal 2");
        Terminal t3=new Terminal(caj, "Terminal 3");
        t1.start();
        t2.start();
        t3.start();
        Thread.sleep(4000);
        System.out.println("El " +t1.mostrarNombre()+" vendió : "+t1.mostrarLocalidades()+" localidades");
        System.out.println("El " +t2.mostrarNombre()+" vendió : "+t2.mostrarLocalidades()+" localidades");
        System.out.println("El " +t3.mostrarNombre()+" vendió : "+t3.mostrarLocalidades()+" localidades");
       System.out.println("Total de unidades vendidas : "+caj.mostrarLocalidades());
       System.out.println("Fin del programa");
    }
    
}

class Cajero {
    
    Cajero(String name){
        
        nombre=name;
    }

public synchronized void sumarLocalidades(){
    localidades=localidades+1;
}

public synchronized int mostrarLocalidades(){
    
   return  localidades;
}

private String nombre;
private int localidades;

}

class Terminal extends Thread{
    Terminal(Cajero c,String nombre){
        
        this.nombre=nombre;
        Cajero=c;
        
    }
    
    public void run(){
        lock.lock();
        try{
        for(int i=0;i<maxLocalidades;i++){
            Cajero.sumarLocalidades();
            vendoLocalidades();
        }
        }
        finally{ lock.unlock();}
    }
    private void vendoLocalidades(){
        localidades=localidades+1;
    }
    
    public int mostrarLocalidades(){
        return localidades;
    }
    
    public String mostrarNombre(){
        return nombre;
    }
    
    int localidades;
    private final ReentrantLock lock=new ReentrantLock();
    String nombre;
    int maxLocalidades=20000;
    private Cajero Cajero;
}


