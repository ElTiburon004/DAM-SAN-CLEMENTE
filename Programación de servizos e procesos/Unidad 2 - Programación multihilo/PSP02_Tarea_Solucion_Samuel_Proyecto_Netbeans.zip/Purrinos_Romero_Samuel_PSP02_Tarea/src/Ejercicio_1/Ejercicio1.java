/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio_1;

/**
 *
 * @author samuel
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        try {
            Hilo1 HiloA = new Hilo1();
            Hilo2 HiloB = new Hilo2();
            System.out.println("Ejecución en HiloA");
            HiloA.start();
            HiloA.join();
            System.out.println("Ejecución en HiloB");
            HiloB.start();
            HiloB.join();
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        System.out.println("Ejecución en Main");
    }
    
}

class Hilo1 extends Thread {

    public void run(){
        for(int i=0;i<30;i++){
            System.out.println("NO");
        }
        
    }
}

class Hilo2 extends Thread {

    public void run(){
        for(int i=0;i<30;i++){
            System.out.println("YES");
        }
        
    }
}