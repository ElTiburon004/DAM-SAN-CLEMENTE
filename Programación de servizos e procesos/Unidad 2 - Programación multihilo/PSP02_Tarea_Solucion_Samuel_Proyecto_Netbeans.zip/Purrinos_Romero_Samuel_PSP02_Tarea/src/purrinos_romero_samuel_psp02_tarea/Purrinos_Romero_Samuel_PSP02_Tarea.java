/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package purrinos_romero_samuel_psp02_tarea;

/**
 *
 * @author samuel
 */
public class Purrinos_Romero_Samuel_PSP02_Tarea {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
