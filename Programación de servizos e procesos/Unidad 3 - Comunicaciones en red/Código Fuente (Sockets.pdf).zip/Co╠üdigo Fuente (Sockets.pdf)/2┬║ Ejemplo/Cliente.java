/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio17_2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import static java.lang.System.in;
import java.net.Socket;

/**
 *
 * @author Juan Morillo Fernandez
 */
public class Cliente  {
    
        public static void main(String[] args) throws Exception {

            String Host = "localhost";
            int puerto = 6000;// puerto remoto
        
                Socket cliente = new Socket(Host, puerto);

                // CREO FLUJO DE SALIDA AL SERVIDOR
                PrintWriter fsalida = new PrintWriter(cliente.getOutputStream(), true);

                // CREO FLUJO DE ENTRADA AL SERVIDOR
                BufferedReader fentrada = new BufferedReader(new InputStreamReader(cliente.getInputStream()));

                // FLUJO PARA ENTRADA ESTANDAR
                BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

                String cadena, eco="";
                System.out.print("Introduce cadena: ");
                cadena = in.readLine();//lectura por teclado
                while(!cadena.equalsIgnoreCase("Salir")) {
                        fsalida.println(cadena); //envio cadena al servidor
                        eco=fentrada.readLine(); //recibo cadena del servidor
                        System.out.println(" =>ECO: "+eco);
                        System.out.print("Introduce cadena. Pulse Salir para terminar: ");
                        cadena = in.readLine();//lectura por teclado
                }
                fsalida. close () ;
                fentrada.close();
                System.out.println("Fin del envio ... ");
                in.close();
                cliente.close();
        
}
}
