/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UD3.multicast;

/**
 *
 * @author Juan Morillo Fernandez
 */
import java.io.*;
import java.net.*;

//Para probarlo, lanzar el MCServer y despues crear tantas 
//instancias de este como se quiera, espera a que haga el 
//join al grupo tarda unos segundos, y comienza a escribir 
//en la instancia del servidor (lo escrito saldrá en todos 
//estos clientes creados).

public class MCClient
{
        public static void main (String [] args) throws IOException, InterruptedException
        {
            //dependiendo de la red de vuestra casa es necesario o no
            System.setProperty("java.net.preferIPv4Stack", "true");
            //Creamos un socket multicast en el puerto 10000:
            MulticastSocket s = new MulticastSocket (10000);

            //Configuramos el grupo (IP) a la que nos conectaremos:
            InetAddress group = InetAddress.getByName ("231.0.0.1");

            
            //Nos unimos al grupo:
            s.joinGroup (group);

            //Leemos los paquetes enviados por el servidor multicast:
            String salida = new String();
            while(!salida.equals("salir"))
           // while(!("salir".equals(salida)))
            {

                // Los paquetes enviados son de 256 bytes de maximo 
                //(es adaptable)
                byte [] buffer = new byte [256];

                //Creamos el datagrama en el que recibiremos el paquete 
                //del socket:
                DatagramPacket dgp = new DatagramPacket (buffer, buffer.length);

                // Recibimos el paquete del socket:
                s.receive (dgp);

                //Vemos los datos recibidos por pantalla:
                salida = new String (dgp.getData ());
                System.out.println (salida.trim());
               
               
                salida= salida.trim();
            }

    //Salimos del grupo multicast
    s.leaveGroup (group);

    // Cerramos el socket:
    s.close ();
    System.out.println("Socket cerrado ... ");
}

}
