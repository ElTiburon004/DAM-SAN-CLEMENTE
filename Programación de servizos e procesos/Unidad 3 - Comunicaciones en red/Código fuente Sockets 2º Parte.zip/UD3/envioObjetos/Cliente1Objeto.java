/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UD3.envioObjetos;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 *
 * @author jmorillo
 */
public class Cliente1Objeto {
  
    
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        String Host = "localhost";
        int puerto = 6000;
        System.out.println("Programa cliente iniciado ....");
        
        Socket cliente = new Socket (Host,puerto);
        
        ObjectInputStream perEnt = new ObjectInputStream(cliente.getInputStream());
        
        Persona dato = (Persona) perEnt.readObject();
        System.out.println("Recibo"+ dato.getNombre() +"*" + dato.getEdad());
        
        //Modifico el objeto
        dato.setNombre("Juan Ramos");
        dato.setEdad(22);
        
        ObjectOutputStream perSal = new ObjectOutputStream(cliente.getOutputStream());
        
        perSal.writeObject(dato);
        System.out.println("Envio"+ dato.getNombre() +"*" + dato.getEdad());
        
        perEnt.close();
        perSal.close();
        cliente.close();
        
        
    }
}
