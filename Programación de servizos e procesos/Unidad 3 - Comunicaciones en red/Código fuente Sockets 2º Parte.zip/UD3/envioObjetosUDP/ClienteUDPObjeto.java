package UD3.envioObjetosUDP;

/*
Enunciado:

(ENVIO DE OBJETOS SOCKETS UDP). Realiza un programa servidor que espere un datagrama
de un cliente. El cliente le envía un objeto Persona que previamente había inicializado. 
El servidor modifica los datos del objeto Persona y se lo envía de vuelta al cliente. 
Visualiza los datos del objeto Persona tanto en el programa cliente cuando los envía 
y los recibe como en el programa servidor cuando los recibe y los envía modificados. 
 */



import java.io.*;
import java.net.*;
public class ClienteUDPObjeto {
	public static void main(String args[]) throws Exception {
				
		DatagramSocket clientSocket = new DatagramSocket();//socket cliente
		byte[] enviados = new byte[1024];
		byte[] recibidos = new byte[1024];
		
		// DATOS DEL SERVIDOR al que enviar mensaje
		InetAddress IPServidor = InetAddress.getLocalHost() ;// localhost
		int puerto = 9876; //,puerto por el que escucha
		
		//Inicializamos el objeto Persona y lo convertimos a byte.
		Persona persona = new Persona("Maria", 22);
		
                //CONVERTIMOS OBJETO A BYTES
		ByteArrayOutputStream bs= new ByteArrayOutputStream();
		ObjectOutputStream out = new ObjectOutputStream (bs);
		out.writeObject(persona);//escribir objeto Persona en el stream
		out.close(); //cerrar stream
		enviados = bs.toByteArray(); // objeto en bytes
					
		//ENVIANDO DATAGRAMA AL SERVIDOR
		System.out.println ("Envio: "+persona.getNombre () +"*"+persona.getEdad());//Muestra lo que envía.
		DatagramPacket envio = new DatagramPacket(enviados, enviados.length, IPServidor, puerto);
		clientSocket.send(envio) ;
				
		System.out.println ("Esperando datagrama ..... ");
		//RECIBO DATAGRAMA DEL SERVIDOR
		DatagramPacket recibo = new DatagramPacket(recibidos, recibidos.length);
		clientSocket.receive(recibo);
		// CONVERTIMOS BYTES A OBJETO
		ByteArrayInputStream bais = new ByteArrayInputStream(recibidos);
		ObjectInputStream in = new ObjectInputStream(bais);
		persona = (Persona) in.readObject();//obtengo objeto
		in.close();
		//Muestra lo que recibe.
		System.out.println ("Recibo: "+persona.getNombre () +"*"+persona.getEdad()) ;
					
				
		clientSocket.close();//cerrar socket
	}
}