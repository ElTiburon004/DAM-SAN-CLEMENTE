package UD3.envioObjetosUDP;

/*(ENVIO DE OBJETOS SOCKETS UDP). Realiza un programa servidor que espere un datagrama
de un cliente. El cliente le envía un objeto Persona que previamente había inicializado. 
El servidor modifica los datos del objeto Persona y se lo envía de vuelta al cliente. 
Visualiza los datos del objeto Persona tanto en el programa cliente cuando los envía 
y los recibe como en el programa servidor cuando los recibe y los envía modificados. 
(La clase persona ya la tienes creada en los apuntes de teoría). */



import java.io.*;
import java.net.*;


public class ServidorUDPObjeto {
public static void main(String args[]) throws Exception {
		//Puerto por el que escucha el servidor: 9876
		DatagramSocket serverSocket = new DatagramSocket(9876);
		byte[] recibidos = new byte[1024];
		byte[] enviados = new byte[1024];
				
	
			System.out.println ("Esperando datagrama ..... ");
			//RECIBO DATAGRAMA
			recibidos = new byte[1024];
			DatagramPacket paqRecibido = new DatagramPacket(recibidos, recibidos.length);
			serverSocket.receive(paqRecibido);
			
                        // CONVERTIMOS BYTES A OBJETO
			ByteArrayInputStream bais = new ByteArrayInputStream(recibidos);
			ObjectInputStream in = new ObjectInputStream(bais);
			Persona persona = (Persona) in.readObject();//obtengo objeto
			in.close();
			//Muestra lo que recibe.
			System.out.println ("Recibo: "+persona.getNombre () +"*"+persona.getEdad()) ;
			
			//DIRECCION ORIGEN.Necesita la IP y puerto de origen para poder responder
			InetAddress IPOrigen = paqRecibido.getAddress();
			int puerto = paqRecibido.getPort();
			//System.out.println ("\tOrigen: " + IPOrigen + ":" + puerto);
			//System.out.println ("\tMensaje recibido: " + cadena.trim());
			
			//Modifica persona.
			persona.setNombre("María de la O");
			persona.setEdad(25);
			
			//CONVERTIMOS OBJETO A BYTES
			ByteArrayOutputStream bs= new ByteArrayOutputStream();
			ObjectOutputStream out = new ObjectOutputStream (bs);
			out.writeObject(persona);//escribir objeto Persona en el stream
			out.close(); //cerrar stream
			enviados = bs.toByteArray(); // objeto en bytes
					
			//ENVIANDO DATAGRAMA AL CLIENTE
			System.out.println ("Envio: "+persona.getNombre () +"*"+persona.getEdad());//Muestra lo que envía.
			DatagramPacket envio = new DatagramPacket(enviados, enviados.length, IPOrigen, puerto);
			serverSocket.send(envio);
			
				
		serverSocket.close() ;
		System.out.println ("Socket cerrado ... ");
		}
}