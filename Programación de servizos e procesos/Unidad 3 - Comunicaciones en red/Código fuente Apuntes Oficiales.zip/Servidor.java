/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apuntes_ofi;

import java.io.* ;
import java.net.* ;
import java.util.logging.Level;
import java.util.logging.Logger;
class Servidor {
    static final int Puerto=2000;
    
    public Servidor( ) {
    
       
        try {
            // Inicio la escucha del servidor en un determinado puerto
            ServerSocket skServidor = new ServerSocket(Puerto);
            System.out.println("Escucho el puerto " + Puerto );
            // Espero a que se conecte un cliente y creo un nuevo socket para el cliente
            Socket sCliente = skServidor.accept();
            // ATENDER PETICIÓN DEL CLIENTE
            // Cierro el socket
            sCliente.close();
        } catch (Exception e) {
            System.out.println( e.getMessage() );
        }
        
   
}
public static void main( String[] arg ) throws IOException {
    
     Servidor server = new Servidor();
 }
}
