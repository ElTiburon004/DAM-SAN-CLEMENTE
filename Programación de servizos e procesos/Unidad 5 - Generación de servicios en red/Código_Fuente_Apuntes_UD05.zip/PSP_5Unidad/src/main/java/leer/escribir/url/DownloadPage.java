/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leer.escribir.url;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

/**
 *
 * @author jmor
 */
public class DownloadPage {
    public static void main(String[] args) throws MalformedURLException, IOException {
        
        String url = "https://google.com";
        String filePath = "Google.html";
 
        URL urlObj = new URL(url);
        URLConnection urlCon = urlObj.openConnection();

        InputStream inputStream = urlCon.getInputStream();
        BufferedInputStream reader = new BufferedInputStream(inputStream);

        BufferedOutputStream writer = new BufferedOutputStream(new FileOutputStream(filePath));

        byte[] buffer = new byte[4096];
        int bytesRead = -1;

        while ((bytesRead = reader.read(buffer)) != -1) {
            writer.write(buffer, 0, bytesRead);
        }

        writer.close();
        reader.close();
            }
}
