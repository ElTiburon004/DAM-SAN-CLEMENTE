package ejemplos.url;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Scanner;
/**
 *
 * @author Juan Morillo Fernandez
 */
/*
Enunciado: desarrolla un pequeño programa en java que simule los comandos de red
nslookup y host

*/

public class Ejercicio15_2 {
   
    static void ObtenerIP(String URL){//Método que dada
		//una URL devuelve su IP.
		try{
			InetAddress direccion = InetAddress.getByName(URL);
			//Obtener direccion del host del nodo anterior
			System.out.println("IP: "+direccion.getHostAddress());
		
		} catch (UnknownHostException e){
			System.out.println("La URL no existe");
		}
	
	}

	static void ObtenerDir(String IP){//Método que dada
		//una IP devuelve su URL.
		try{
			InetAddress direccion = InetAddress.getByName(IP);
			//Obtener IP del nodo anterior
			System.out.println("IP: "+direccion.getHostName());
		
		} catch (UnknownHostException e){
			System.out.println("La URL no existe");
		}
	
	}

	public static void main(String[] args){
		//pedimos la opción elegida por teclado.
		Scanner teclado=new Scanner(System.in);
		//Creamos e inicializamos variables.
		InetAddress direccion=null;
		int opcion=0;
		
		//Se ejecuta el bucle mientras no 
		//elijamos la opcion 3, salir.
		while(opcion!=3){
			System.out.println("\n1.- Obtener la dirección IP");
			System.out.println("2.- Obtener la URL");
			System.out.println("3.- Salir");
			System.out.print("Seleccione una opción: ");
			opcion=teclado.nextInt(); //Leo la opcion tecleada
			
			//Hacemos una cosa u otra según la opción elegida.
			switch (opcion){
			case 1:{System.out.print("Escribe la dirección: ");
					//Se lee la direccion.
					teclado.nextLine();//Si no ponemos esta línea no se
					//para a leer la URL.
					String nodo=teclado.nextLine();
					ObtenerIP(nodo);
					break;}
			case 2:{System.out.print("Escribe la IP: ");
					//Se lee la IP.
					teclado.nextLine();//Si no ponemos esta línea no se
					//para a leer la IP.
					String nodo=teclado.nextLine();
					ObtenerDir(nodo);
					break;}
			case 3: break;
			default: System.out.println("Opción no válida");
			}
		
		
		}
		
	
	}

}

