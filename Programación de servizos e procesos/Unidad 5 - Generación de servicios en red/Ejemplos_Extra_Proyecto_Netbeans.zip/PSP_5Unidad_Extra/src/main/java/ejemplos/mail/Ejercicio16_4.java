/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplos.mail;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.net.pop3.POP3MessageInfo;
import org.apache.commons.net.pop3.POP3SClient;

/**
 *
 * @author juan
 */
public class Ejercicio16_4 {
    
     public static void main(String [] args) {
     
     
         try {
             String server="pop.gmail.com";
             String username="XXXXX@gmail.com";
             String pass="XXX";
             String linea=null;
             int puerto= 995;
             POP3SClient client= new POP3SClient(true);
             
             client.connect(server, puerto);
             
             if(!client.login(username, pass)){
                 System.out.println("Error al conectarse");
                 System.exit(1);
             }
       
             
             //Obtener info del mail de varias formas
             
             POP3MessageInfo[] mensajes =  client.listMessages();
             for (int i=0; i< mensajes.length; i++) {
		System.out.println("Mensaje: " + (i+1));
		POP3MessageInfo msginfo =mensajes[i]; //lista de mensajes
		System.out.println("IDentificador: " + msginfo.identifier + ", Number: " + msginfo.number + 				",Tamaño: " + msginfo.size);

                System.out.println("Prueba de listUniqueIdentifier: ");
		POP3MessageInfo pmi = client.listUniqueIdentifier(i+1) ;//un mensaje
		System.out.println("\tIDentificador: " + pmi.identifier +
			", Number: " + pmi.number + ", Tamaño: " + pmi.size);
            }//for
             
             
             
          //Obtener el cuerpo con retrieveMessaage o retriveMessageTop para cabecera 
           BufferedReader reader =(BufferedReader) client.retrieveMessage(1);
          
          while ((linea = reader.readLine()) != null)
		System.out.println(linea.toString());
          reader.close();
          client.logout();
          client.disconnect();
             
         } catch (IOException ex) {
             Logger.getLogger(Ejercicio16_4.class.getName()).log(Level.SEVERE, null, ex);
         }
     
     
     }
}
