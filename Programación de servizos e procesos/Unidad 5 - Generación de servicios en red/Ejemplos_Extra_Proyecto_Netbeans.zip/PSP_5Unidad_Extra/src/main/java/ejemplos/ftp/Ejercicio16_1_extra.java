/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplos.ftp;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;

/**
 *
 * @author juan
 */
/*
Enunciado:
Subir un fichero a un servidor FTP

*/
public class Ejercicio16_1_extra {
   
    public static void main(String [] args){
    
        FTPClient client = new FTPClient();
        String sFTP = "ftp.rediris.es";
        String sUser = "anonymous";
        String sPassword = "";
 
        try {
            client.connect(sFTP);
            boolean login = client.login(sUser,sPassword);
            if (login){
                System.out.println("Usuario correcto");
                
                String dir= "/NUEVODIRECTORIO";
                client.changeWorkingDirectory(dir);
                client.setFileType(FTP.BINARY_FILE_TYPE);
                
                BufferedInputStream in= new BufferedInputStream(new FileInputStream("foto.jpg"));
                client.storeFile("archivo_subido", in);
                in.close();
                
            }else{
                System.out.println("Usuario incorrecto");
                client.disconnect();
                System.exit(1);
            }
            
           
            
            boolean logout = client.logout();
            if (logout){ System.out.println("Desconectando...");}
            else{System.out.println("Error al hacer logout...");}
            client.disconnect();
            
            /*
            Más funcionalidades
            
            Renombrar fichero:
            if(client.rename("antiguo","nuevo"))
            
            Eliminar fichero:
            if(client.deleteFile("nombre fichero"))
            
            
            */
            
            
        } catch (IOException ioe) {ioe.printStackTrace();}
    }
}
