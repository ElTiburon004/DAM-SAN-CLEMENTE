/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplos.mail;

import java.io.IOException;
import java.io.Writer;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.net.smtp.AuthenticatingSMTPClient;
import org.apache.commons.net.smtp.SMTPClient;
import org.apache.commons.net.smtp.SMTPReply;
import org.apache.commons.net.smtp.SimpleSMTPHeader;

/**
 *
 * @author juan
 * 
 * ********Aviso
 * Esta sería la forma de enviar emails sin SSL, pero hoy por hoy no he encontrado 
 * ningún proveedor que lo permita. Probar EnviarCorreoSSL.java
 */
public class EnviarEmail {
   
        public static void main(String [] args) throws IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidKeySpecException, Exception{
        
        
        sendEmail();
        }
      
        
        
  public static void sendEmail() throws Exception {  
    
    Scanner sc= new Scanner(System.in);  
    String hostname = "****";
    int port = 465;
  
    //System.out.println("Introduzca su contraseña");
    String password = "******";
    //password= sc.nextLine();
    String login = "****";
  
    String from = login;
  
    String subject = "subject" ;
    String text = "message";
  
    AuthenticatingSMTPClient client = new AuthenticatingSMTPClient();
    try {
      String to = "xxxxxx@xxxxx";
       client.connect(hostname, port);
      // si el servidor acepta TLS
      if (client.execTLS()) {
  
        client.auth(AuthenticatingSMTPClient.AUTH_METHOD.LOGIN, login, password);
        checkReply(client);
  
        client.setSender(from);
        checkReply(client);
  
        client.addRecipient(to); //se puede agregar más destinatarios
        checkReply(client);
        
        Writer writer = client.sendMessageData();
       
        //Cuerpo del mail
        
        if (writer != null) {
          SimpleSMTPHeader header = new SimpleSMTPHeader(from, to, subject);
          writer.write(header.toString());
          writer.write(text);
          writer.close();
          if(!client.completePendingCommand()) {// failure
            throw new Exception("Failure to send the email "+ client.getReply() + client.getReplyString());
          }
        } else {
          throw new Exception("Failure to send the email "+ client.getReply() + client.getReplyString());
        }
      } else {
        throw new Exception("STARTTLS was not accepted "+ client.getReply() + client.getReplyString());
      }
    } catch (Exception e) {
        throw e;
    } finally {
        client.logout();
        client.disconnect();
    }
  }
  
  private static void checkReply(SMTPClient sc) throws Exception {
    if (SMTPReply.isNegativeTransient(sc.getReplyCode())) {
      throw new Exception("Transient SMTP error " + sc.getReply() + sc.getReplyString());
    } else if (SMTPReply.isNegativePermanent(sc.getReplyCode())) {
      throw new Exception("Permanent SMTP error " + sc.getReply() + sc.getReplyString());
    }     
}
}
