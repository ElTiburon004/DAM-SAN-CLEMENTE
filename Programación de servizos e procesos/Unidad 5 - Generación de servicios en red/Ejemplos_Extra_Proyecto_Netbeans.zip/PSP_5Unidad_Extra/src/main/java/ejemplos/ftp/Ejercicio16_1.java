/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplos.ftp;

import java.io.IOException;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;

/**
 *
 * @author juan
 */
/*
Enunciado:
1. Realizar un programa en Java que se conecte a ftp.rediris.es y 
visualice los directorios del directorio raíz, entre después en cada directorio
del directorio raíz mostrando la lista de ficheros y directorios que hay. 
Probar en otros servidores FTP que admiten usuarios anónimos como 
ftp.mozilla.org, ftp.freebsd.org, etc.


*/
public class Ejercicio16_1 {
   
    public static void main(String [] args){
    
        FTPClient client = new FTPClient();
        String sFTP = "ftp.rediris.es";
        String sUser = "anonymous";
        String sPassword = "";
 
        try {
            client.connect(sFTP);
            boolean login = client.login(sUser,sPassword);
            if (login){
                System.out.println("Usuario correcto");
            }else{
                System.out.println("Usuario incorrecto");
                client.disconnect();
                System.exit(1);
            }
            
            System.out.println("El directorio actual es:"+ client.printWorkingDirectory());
            FTPFile [] files= client.listFiles();
            
            //array para visualizar tipos de ficheros
            String[] tipos= {"Fichero", "Directorio", "Enlace simbólico"};
            
            for (FTPFile file : files) {
                    String details = file.getName();
                    if (file.isDirectory()) {
                        details = "[" + details + "]";
                    }
                    details += "\t\t tamaño:" + file.getSize();
                    details += "\t\t tipo:" + tipos[file.getType()];
                    System.out.println(details);
            }
            boolean logout = client.logout();
            if (logout){ System.out.println("Desconectando...");}
            else{System.out.println("Error al hacer logout...");}
            client.disconnect();
            
        } catch (IOException ioe) {ioe.printStackTrace();}
    }
}
