package ejemplos.url;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Juan Morillo Fernandez
 */
import java.net.*;

public class Ejercicio15_1
{
    public static void main(final String[] array) {
        System.out.println("===========================================");
        System.out.println("SALIDA PARA LOCALHOST: ");
        try {
            pruebaMetodos(InetAddress.getByName("localhost"));
            System.out.println("==========================================");
            System.out.println("SALIDA PARA UNA URL:");
            final InetAddress byName = InetAddress.getByName("www.google.es");
            pruebaMetodos(byName);
            System.out.println(" \tDIRECCIONES IP PARA: " + byName.getHostName());
            
            //método para averiguar varias IPs de un mismo host
            final InetAddress[] allByName = InetAddress.getAllByName(byName.getHostName());
            for (int i = 0; i < allByName.length; ++i) {
                System.out.println("\t\t" + allByName[i].toString());
            }
            System.out.println("==========================================");
        }
        catch (UnknownHostException ex) {
            ex.printStackTrace();
        }
    }
    
    private static void pruebaMetodos(final InetAddress inetAddress) {
        System.out.println("\tMetodo getByName(): " + inetAddress);
        try {
            System.out.println("\tMetodo getLocalHost(): " + InetAddress.getLocalHost());
        }
        catch (UnknownHostException ex) {
            ex.printStackTrace();
        }
        System.out.println("\tMetodo getHostName(): " + inetAddress.getHostName());
        System.out.println("\tMetodo getHostAddress(): " + inetAddress.getHostAddress());
        System.out.println("\tMetodo toString(): " + inetAddress.toString());
        //CNAME del host
        System.out.println("\tMetodo getCanonicalHostName(): " + inetAddress.getCanonicalHostName());
    }
}