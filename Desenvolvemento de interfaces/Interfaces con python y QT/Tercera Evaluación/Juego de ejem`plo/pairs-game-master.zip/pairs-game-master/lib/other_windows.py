
# -*- coding: utf-8 -*-
"""
Módulo que contén a definición das fiestras QMainWindow secundarias da aplicación
"""
from PySide2 import QtCore
from PySide2.QtCore import QUrl, QFileInfo
from PySide2.QtGui import QPixmap
from PySide2.QtWidgets import QMainWindow, QVBoxLayout, QHBoxLayout, QLabel, QWidget
from PySide2.QtWebEngineWidgets import QWebEngineView, QWebEngineSettings
from lib.options import Options


class PdfWindow(QMainWindow):
    """ Fiestra secundaria na que se carga un PDF para ser visualizado facendo uso do compoñente
    QWebEngineView de Qt"""

    def __init__(self, parent=None):
        """Construtor da clase."""
        super(PdfWindow, self).__init__(parent)
        self.setWindowTitle(Options.TR_("Manual de usuario"))
        self.web = QWebEngineView()
        self.web.settings().setAttribute(QWebEngineSettings.PluginsEnabled, True)
        self.web.settings().setAttribute(QWebEngineSettings.FullScreenSupportEnabled, True)
        self.web.settings().setAttribute(QWebEngineSettings.PdfViewerEnabled, True)
        self.setCentralWidget(self.web)

    def showPdf(self, path_to_file: str):
        """Método que recibe a ruta do ficheiro PDF que queremos visualizar para cargalo
        nesta fiestra secundaria, e unha vez o carga na mesma, esta amósase de xeito 
        maximizado

        Args:
            path_to_file (str): Ruta ao ficheiro PDF que queremos amosar
        """
        try:
            absolute_path = QFileInfo(path_to_file).absoluteFilePath()
            url_to_manual = QUrl.fromLocalFile(absolute_path)
            self.web.load(url_to_manual)
            self.showMaximized()
        except Exception as e:
            print(str(e))


class AboutWindow(QMainWindow):
    """ Fiestra secundaria na que se amosa a información referente á aplicación"""

    def __init__(self, parent=None):
        """Construtor da clase."""
        super(AboutWindow, self).__init__(parent)
        self.setWindowTitle(Options.TR_("Sobre a aplicación"))
        self.setGeometry(400, 350, 300, 140)

        vbox_layout = QVBoxLayout()
        self.label_title = QLabel(Options.__PROJECT__)
        self.label_title.setStyleSheet("font: 30pt Comic Sans MS")
        self.label_author = QLabel(Options.__AUTHOR__)
        self.label_license = QLabel(Options.__LICENSE__ + " " + Options.__VERSION__)
        self.label_email = QLabel(Options.__EMAIL__)
        self.data_widget = QWidget()
        vbox_layout.addWidget(self.label_title)
        vbox_layout.addWidget(self.label_author)
        vbox_layout.addWidget(self.label_license)
        vbox_layout.addWidget(self.label_email)
        self.data_widget.setLayout(vbox_layout)

        self.label_image = QLabel()
        pixmap = QPixmap(Options.__LOGO__)
        pixmap = pixmap.scaled(120, 120, QtCore.Qt.KeepAspectRatio)
        self.label_image.setPixmap(pixmap)

        self.central_widget = QWidget()
        hbox_layout = QHBoxLayout()
        hbox_layout.addWidget(self.label_image)
        hbox_layout.addSpacing(30)
        hbox_layout.addWidget(self.data_widget)
        self.central_widget.setLayout(hbox_layout)

        self.setCentralWidget(self.central_widget)
