# -*- coding: utf-8 -*-
"""
Este módulo contén a definición do fío secundario da aplicación
"""
import time
from PySide2.QtCore import QThread, Signal, QObject
from lib.options import Options


class ProcessSignal(QObject):
    """Clase que extende a un obxecto base :class:`PySide2.QtCore.QObject` da libraría Qt
    que define un único atributo de tipo :class:`PySide2.QtCore.Signal`.
    Esta clase é usada polo fío secundario da aplicación que usamos para realizar accións en
    segundo plano de xeito que o fío da aplicación principal non se quede "conxelada" ao
    procesar ditas accións.
    """
    sig = Signal(Options.Action)


class ProcessThread(QThread):
    """Clase que define o fío secundario da aplicación usado para realizar accións en segundo
    plano de xeito que o fío da aplicación principal non se quede "conxelada" ao procesar ditas
    accións e estende á clase base :class:`PySide2.QtCore.QThread`

    Args:
        parent (PySide2.QtCore.QObject): O elemento pai desde o que se inicializa o fío. Por
            defecto é None

    Attributes:
        __actions (list): Listado de accións que funciona como unha cola dentro do fío.
        signal (ProcessSignal): Obxecto de tipo QObject que contén a sinal que emite ao fío 
            principal as accións a realizar.
    """
    def __init__(self, parent=None):
        """Construtor da clase."""
        QThread.__init__(self, parent)
        self.__actions = []

        self.signal = ProcessSignal()

    def run(self):
        """Función que inicia a execución do fío que controla as opcións da aplicación en segundo
            plano.
        """
        while not self.isInterruptionRequested():
            time.sleep(0.3)
            action = self.getAction()
            if (action is None):
                Options.LOG.info("Non fai nada")
                continue
            elif (action == Options.Action.UPDATE_CARDS):
                time.sleep(1.1)
                self.signal.sig.emit(Options.Action.UPDATE_CARDS)
                Options.LOG.info("Imos limpar o taboleiro emitindo a sinal: " + str(Options.Action.UPDATE_CARDS))
            elif (action == Options.Action.NEW_LEVEL):
                self.signal.sig.emit(Options.Action.NEW_LEVEL)
                Options.LOG.info("Imos subir de nivel emitindo a sinal: " + str(Options.Action.NEW_LEVEL))

    def getAction(self):
        """Obtén a primeira acción da lista de accións e elimínaa da mesma (funcionamento xeral dunha cola).
        Se a lista está baleira devolve `None`
        
        Args:
            action (Options.Action): Acción que imos engadir para lanzar a execución a través do fío en segundo plano
        
        Returns:
            Options.Action: Devolve o primeiro elemento da cola se existe, e en caso contrario devolve `None`
        """
        if (self.__actions != []):
            return self.__actions.pop(0)
        return None

    def addAction(self, action: Options.Action):
        """Engade unha acción para executar desde o fío secundario da aplicación.

        Args:
            action (Options.Action): Acción que imos engadir para lanzar a execución a través do fío en segundo plano
        """
        self.__actions.append(action)


    def stop(self):
        self.requestInterruption()
        self.wait()
