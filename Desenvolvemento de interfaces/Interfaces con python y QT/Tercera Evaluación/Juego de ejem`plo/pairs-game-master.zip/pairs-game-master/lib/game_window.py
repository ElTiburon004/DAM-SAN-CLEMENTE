# -*- coding: utf-8 -*-
"""
Módulo principal do xogo encargado de controlar e inicializar todos os compoñentes visuais.
"""
from PySide2 import QtGui
from PySide2.QtCore import QTimer
from PySide2.QtWidgets import QMainWindow, QAction, QLabel, QWidget, QVBoxLayout, \
    QHBoxLayout, QLCDNumber, QMessageBox, QToolTip
from PySide2.QtGui import QIcon, QFont
from lib.options import Options
from lib.board import Board
from lib.process_thread import ProcessThread
from lib.other_windows import PdfWindow, AboutWindow


class GameWindow(QMainWindow):
    """ Clase principal do xogo, trátase dun compoñente que estende á clase base QMainWindow
    de PySide2 (binding Qt) sobre o que se cargan todos os compoñentes que forman parte do
    xogo das parellas

    Attributes:
        __game_thread (ProcessThread): Compoñente pai que contén o taboleiro (fiestra
            principal da aplicación)
        __rows (int): Número de filas de tarxetas.
        __cols (int): Número de columnas de tarxetas.
        __cards_number (int): Número de tarxetas totais que conterá o taboleiro.
        __card_positions (list):  Listado de posicións enteiras que se calculan de xeito
            aleatorio e que serán as que indiquen as posicións de cada tarxetas. O listado
            terá un tamaño igual ao número de tarxetas a colocar no taboleiro segundo o
            nivel do xogo.
        __level (int): Nivel do xogo, comeza en 1
        __time_seconds (int): Tempo máximo en segundos para superar o nivel no que nos
            atopamos no xogo. Indica os segundos nos que comezará a conta atrás.
        __game_end (bool): Indica se o xogo finalizou. ´Usase como variable de control.
        pairs_cards (list): Listado que conterá os pares de cartas a utilizar, é dicir
            elementos do tipo PairCards
    """

    def __init__(self):
        """Construtor da clase."""
        super().__init__()
        self.__level = 1
        self.__cards_number = 0
        self.setStyleSheet(Options.TMP_QWIDGET_BG_COLOR % Options.COLORS["bg_main_window"])

        # Inicializa o fío
        self.__game_thread = ProcessThread()
        self.__game_thread.start()
        self.__game_thread.signal.sig.connect(self.executeAction)
        self.__game_end = False

        self.setWindowTitle(Options.TR_("XOGO DAS PARELLAS"))
        self.setWindowIcon(QIcon(Options.__LOGO__))
        self.setGeometry(300, 300, 700, 500)
        self.createMenu()
        self.createNewGame()

    def executeAction(self, data: Options.Action):
        """Realizar a acción indicada. Este método é invocado desde self.____game_thread
        pois é conectado coa sinal definida nese fío secundario da aplicación que se
        executa en segundo plano

        Args:
            data (Options.Action): Acción a realizar
        """
        Options.LOG.info("Vaise realizar a acción '" + str(data) + "' emitida desde o fío secundario")
        if (data == Options.Action.UPDATE_CARDS):
            self.getBoard().updateBoard()
        elif (data == Options.Action.NEW_LEVEL):
            self.increaseLevel()

    def closeEvent(self, event):
        """Sobreescribimos o método closeEvent de QMainWindow para poder pedir a
        confirmación de peche en determinadas ocasións. No caso de que o xogo se
        atope finalizado self.__game_end = True non o fai, en caso contrario sempre
        pedirá confirmación

        Args:
            event (QCloseEvent): Contén os datos do evento de peche da fiestra nese
                intre
        """
        if (self.__game_end):
            self.exitApp()
        else:
            result = QMessageBox.question(self,
                                          Options.TR_("Confirma saída..."),
                                          Options.TR_("Está seguro que quere saír?"),
                                          QMessageBox.Yes | QMessageBox.No)
            event.ignore()

            if result == QMessageBox.Yes:
                event.accept()
                self.exitApp()

    def createMenu(self):
        """Crea o menú principal da aplicación con todos os seus compoeñentes"""
        QToolTip.setFont(QFont("Decorative", 10, QFont.Bold))

        file_menu = self.menuBar().addMenu(Options.TR_("Arquivo"))
        file_menu.setToolTipsVisible(True)  # Habilitamos a axuda contextual

        open_action = QAction(QIcon(Options.ICONS["new"]), Options.TR_("Novo"), self)
        open_action.setShortcut("Ctrl+N")
        open_action.setToolTip(Options.TR_("Comezar un novo xogo"))
        open_action.triggered.connect(self.createNewGame)

        exit_action = QAction(QIcon(Options.ICONS["exit"]), Options.TR_("Saír"), self)
        exit_action.setToolTip(Options.TR_("Saír do xogo"))
        exit_action.setShortcut("Ctrl+X")
        exit_action.triggered.connect(self.exitApp)

        file_menu.addAction(open_action)
        file_menu.addAction(exit_action)

        help_menu = self.menuBar().addMenu(Options.TR_("Axuda"))
        help_menu.setToolTipsVisible(True)  # Habilitamos a axuda contextual

        manual_action = QAction(QIcon(Options.ICONS["manual"]), Options.TR_("Manual da aplicación"), self)
        manual_action.setToolTip(Options.TR_("Descargar o manual de axuda"))
        manual_action.setShortcut("Ctrl+H")
        manual_action.triggered.connect(self.viewManual)

        about_action = QAction(QIcon(Options.ICONS["about"]), Options.TR_("Sobre a aplicación"), self)
        about_action.setToolTip(Options.TR_("Información sobre a aplicación"))
        about_action.setShortcut("Ctrl+H")
        about_action.triggered.connect(self.aboutHelp)

        help_menu.addAction(manual_action)
        help_menu.addAction(about_action)

    def viewManual(self):
        """Visualiza o manual do usuario, que é un PDF que amosa nunha fiestra de tipo PdfWindow"""
        self.pdf_window = PdfWindow(self)
        self.pdf_window.showPdf("doc/manual.pdf")

    def aboutHelp(self):
        """Amosa información sobre a aplicación nunha fiestra de tipo AboutWindow"""
        self.about_window = AboutWindow(self)
        self.about_window.show()

    def updateCountdown(self):
        """Actualizar o contador da aplicación en caso de que sexa maior que 0, resta 1 (segundo) e
        en caso de que sexa <= 0 entón para o temporizador (self.timer) e amosa que o xogador perdeu"""
        if (self.__time_seconds > 0):
            self.__time_seconds -= 1
            self.qlcd_countdown_time.display(self.__time_seconds)
        else:
            self.timer.stop()
            self.lostGame()

    def initCountdown(self):
        """Inicializa o contador da aplicación para o nivel seleccionado que se amosa na parte superior"""
        self.__time_seconds = Options.LEVELS[self.__level-1]["time"]
        self.label_countdown = QLabel(Options.TR_("Tempo"))
        self.label_countdown.setToolTip(Options.TR_("Tempo restante do xogo"))

        self.qlcd_countdown_time = QLCDNumber()
        self.qlcd_countdown_time.setPalette(QtGui.QColor(Options.COLORS["lcd_font_color"]))
        self.qlcd_countdown_time.setDigitCount(4)
        # Modificamos a cor de fondo indicando a mesma mediante un string co formato #RRGGBB
        self.qlcd_countdown_time.setStyleSheet(Options.TMP_QWIDGET_BG_COLOR % Options.COLORS["bg_countdown"])
        self.qlcd_countdown_time.display(self.__time_seconds)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.updateCountdown)
        self.timer.start(1000)  # Indica en milisegundos (1 segundo), cada canto tempo invoca ao método co que
        # está conectado (self.updateCountdown) encargado de facer a conta atrás

    def updateRemainingAttempts(self):
        """Actualizar o número de intentos que quedan, no caso de que sexa maior que 0, resta 1 (segundo) e
        en caso de que sexa <= 0 entón o xogador superou os intentos máximos e amosa que o xogador perdeu"""
        if (self.__remaining_attempts > 0):
            self.__remaining_attempts -= 1
            self.qlcd_remaining_attempts.display(self.__remaining_attempts)
        else:
            self.lostGame()

    def initRemainingAttempts(self):
        """Inicializa o número de intentos de emparellamentos da aplicación para o nivel seleccionado
        que se amosa na parte superior"""
        self.__remaining_attempts = Options.LEVELS[self.__level-1]["attempts"]
        self.label_attempts = QLabel(Options.TR_("Intentos"))
        self.label_attempts.setToolTip(Options.TR_("Número de intentos restantes"))

        self.qlcd_remaining_attempts = QLCDNumber()
        self.qlcd_remaining_attempts.setPalette(QtGui.QColor(Options.COLORS["lcd_font_color"]))
        self.qlcd_remaining_attempts.setDigitCount(4)
        # Modificamos a cor de fondo indicando a mesma mediante un string co formato #RRGGBB
        self.qlcd_remaining_attempts.setStyleSheet(Options.TMP_QWIDGET_BG_COLOR % Options.COLORS["bg_attempts"])
        self.qlcd_remaining_attempts.display(self.__remaining_attempts)

    def initLevel(self):
        """Inicializa o nivel seleccionado que se amosa na parte superior"""
        self.label_level = QLabel(Options.TR_("Nivel"))
        self.qlcd_level = QLCDNumber()
        self.qlcd_level.setPalette(QtGui.QColor(Options.COLORS["lcd_font_color"]))
        self.qlcd_level.setDigitCount(2)
        # Modificamos a cor de fondo indicando a mesma mediante un string co formato #RRGGBB
        self.qlcd_level.setStyleSheet(Options.TMP_QWIDGET_BG_COLOR % Options.COLORS["bg_level"])
        self.qlcd_level.display(self.__level)

    def update_pairs(self):
        """Cada vez que se emparella correctamente dúas tarxetas, invócase a este método de xeito que
         incrementa o contador de parellas que hai na parte superior, e se están emparelladas todas
         as tarxetas dese nivel, entón invoca ao método que pasa o seguinte self.increaseLevel()"""
        self.__pairs += 1
        self.qlcd_pairs.display(self.__pairs)
        if (self.__pairs == self.__total_pairs):
            self.increaseLevel()

    def initPairs(self):
        """Inicializa o número de parellas realizadas. Cando comeza cada nivel ponse a 0"""
        self.__pairs = 0
        self.label_pairs = QLabel(Options.TR_("Pares"))
        self.qlcd_pairs = QLCDNumber()
        self.qlcd_pairs.setPalette(QtGui.QColor(Options.COLORS["lcd_font_color"]))
        self.qlcd_pairs.setDigitCount(4)
        # Modificamos a cor de fondo indicando a mesma mediante un string co formato #RRGGBB
        self.qlcd_pairs.setStyleSheet(Options.TMP_QWIDGET_BG_COLOR % Options.COLORS["bg_pairs"])
        self.qlcd_pairs.display(self.__pairs)

    def createScoreboard(self):
        """Inicializa o tableiro superior de puntuación onde se amosa os elementos todos: nivel do xogo
        parellas realizadas, temporizador e número de intentos de emparellamento"""
        self.initLevel()
        self.initPairs()
        self.initCountdown()
        self.initRemainingAttempts()

        hbox_layout = QHBoxLayout()
        # Add Level
        hbox_layout.addWidget(self.label_level)
        hbox_layout.addWidget(self.qlcd_level)
        hbox_layout.addSpacing(20)
        # Add Level
        hbox_layout.addWidget(self.label_pairs)
        hbox_layout.addWidget(self.qlcd_pairs)
        hbox_layout.addStretch(100)

        # Add countdown
        hbox_layout.addWidget(self.label_countdown)
        hbox_layout.addWidget(self.qlcd_countdown_time)
        hbox_layout.addSpacing(20)
        # Add remaining attempts
        hbox_layout.addWidget(self.label_attempts)
        hbox_layout.addWidget(self.qlcd_remaining_attempts)

        self.scoreboard = QWidget()
        self.scoreboard.setLayout(hbox_layout)

    def createNewGame(self):
        """Método principal desta clase, encargado de crear un novo do xogo, xera un novo panel 
        de puntuación e un taboleiro de tarxetas a emparellar. En función do nivel do xogo
        o panel de puntuación terá uns datos, e o taboleiro un determinado número de tarxetas 
        para emparellar"""
        self.__rows = Options.LEVELS[self.__level-1]["rows"]
        self.__cols = Options.LEVELS[self.__level-1]["cols"]
        self.__total_pairs = (self.__rows*self.__cols)//2

        self.hide()
        self.createScoreboard()
        self.__board = Board(self, self.__rows, self.__cols)
        vbox_layout = QVBoxLayout()
        vbox_layout.addWidget(self.scoreboard)
        vbox_layout.addSpacing(30)
        vbox_layout.addWidget(self.__board)

        self.central_widget = QWidget()
        self.central_widget.setLayout(vbox_layout)
        self.setCentralWidget(self.central_widget)

        self.show()

    def increaseLevel(self):
        """Incrementa o nivel do xogo, sempre e cando non se acadara o nivel máximo, nese caso
        amosa unha mensaxe indicando que se finalizou e remata o xogo"""
        self.__level += 1
        if (self.__level <= len(Options.LEVELS)-1):
            reply = QMessageBox.information(self, Options.TR_("Nivel superado"), Options.TR_("Parabéns, pasas ao nivel ") + str(self.__level))
            if reply == QMessageBox.Ok:
                self.createNewGame()
        else:
            self.__game_end = True
            reply = QMessageBox.information(self, Options.TR_("Acadou o final do xogo"), Options.TR_("Parabéns, tes unha grande memoria!"))
            if reply == QMessageBox.Ok:
                self.exitApp()

    def lostGame(self):
        """Amosa unha mensaxe indicando que o xogador perdeu, e consulta se quere continuar xogando ou saír"""
        self.__game_end = True
        result = QMessageBox.question(self,
                                      Options.TR_("Sintoo pero perdeu..."),
                                      Options.TR_("Prema 'Si' se desexa volver a comezar ou 'Non' se desexa saír"),
                                      QMessageBox.Yes | QMessageBox.No)

        if result == QMessageBox.Yes:
            self.createNewGame()
        else:
            self.exitApp()

    def exitApp(self):
        """Sae do xogo, para iso, primeiro finaliza a execución do fío secundario da aplicación self.__game_thread
        e finalmente pecha a fiestra da aplicación principal, é dicir, a si mesmo"""
        self.__game_thread.stop()
        self.close()

    def addActionToGameThread(self, action: Options.Action):
        """Engade unha acción ao fío secundario da aplicación self.__game_thread

        Args:
            action (Options.Action): Acción engadida ao fío para a sú execución
        """
        self.__game_thread.addAction(action)

    def getBoard(self):
        """Devolve o taboleiro que contén as tarxetas no xogo.

        Returns:
            Board: Taboleiro que contén as tarxetas no xogo.
        """
        return self.__board
