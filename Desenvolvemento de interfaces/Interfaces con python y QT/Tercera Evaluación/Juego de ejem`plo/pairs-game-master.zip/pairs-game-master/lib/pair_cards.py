# -*- coding: utf-8 -*-
"""
Este módulo contén a clase 'pair_cars' usada para manexar o par de cartas
da aplicación.
"""
import uuid
from enum import Enum
from lib.options import Options
from lib.card import Card


class PairCards(object):
    """ Clase usada para representar os pares de tarxetas.
    Ten dous obxectos de tipo card.Card de xeito que haberá unha carta 'A' e outra 'B' que
    compartirán a mesma imaxe e serán as que se emparellen entre elas no xogo, no que
    haberá N pares en función do nivel do xogo.

    Exemplo:
        PairCards(board, pos_card_a, pos_card_b, image)

    Args:
        board (board.Board): Taboleiro que contén o par de tarxetas representado.
        pos_card_a (int): Posición da carta A dentro do taboleiro
        pos_card_b (int): Posició da carta B dentro do taboleiro
        image (str): Imaxe que ten a carta A e B

    Attributes:
        __id (int): Identificado único do obxecto que se xera automaticamente.
        __board (Board): Taboleiro que contén o par de tarxetas representado.
        __card_a (Card): Tarxeta A do par.
        __card_b (Card): Tarxeta B do par.
        __image (str): Ruta á imaxe vinculada ás dúas tarxetas do par.
        __paired (bool): Indica se o par se atopa emparellado. Inicialmente é False.
    """
    class CardType(Enum):
        A = "A"
        B = "B"

    def __init__(self, **kwargs):
        """Construtor da clase."""
        super().__init__()
        self.__id = uuid.uuid4()

        if ("board" in kwargs):
            self.__board = kwargs["board"]
        if ("pos_card_a" not in kwargs):
            raise Exception(Options.TR_("Non se definiu o parámetro 'pos_card_a' "))
        if ("pos_card_b" not in kwargs):
            raise Exception(Options.TR_("Non se definiu o parámetro 'pos_card_b' "))
        if ("image" not in kwargs):
            raise Exception(Options.TR_("Non se definiu o parámetro 'image' "))

        self.__image = kwargs["image"]
        self.__card_a = Card(board=self.__board, pos_number=kwargs["pos_card_a"], image=self.__image)
        self.__card_b = Card(board=self.__board, pos_number=kwargs["pos_card_b"], image=self.__image)
        self.__paired = False

    def isPaired(self):
        """Indica se as cartas están emparelladas

        Returns:
            bool: Devolve True se están emparelladas, False en caso contrario
        """
        return self.__paired

    def setPaired(self, paired: bool):
        """Permite configurar o valor do atributo __paired

        Args:
            paired (bool): Valor que queremos setear
        """
        self.__paired = paired

    def getCard(self, type_card: CardType):
        """Obtén a tarxeta indica a través do parámetro (A ou B)

        Args:
            card (CardType): Tarxeta que desexamos obter

        Returns:
            Card: Devolve a carta do par indicada mediante CardType (A ou B)
        """
        if (type_card == self.CardType.A):
            return self.__card_a
        elif (type_card == self.CardType.B):
            return self.__card_b

    def getId(self):
        """Obtén o identificador único do par de tarxetas

        Returns:
            int: Identificador único do par
        """
        return self.__id
