# -*- coding: utf-8 -*-
"""
Módulo que contén os elementos precisos para representar e manexar o taboleiro sobre o que se amosan
as diferentes tarxetas da aplicacións que debemos emparellar.
"""
import random
from PySide2.QtWidgets import QGridLayout, QWidget
from lib.pair_cards import PairCards
from lib.card import Card
from lib.options import Options


class Board(QWidget):
    """ Clase usada para representar o taboleiro que contén as tarxetas.
    Estende á clase base QWidget de Qt e o seu Layout é de tipo QGridLayout

    Exemplo:
        Board(gamme, rows, cols)

    Args:
        game (GameWindow): Compoñente pai que contén o taboleiro (fiestra
            principal da aplicación)
        rows (int): Número de filas de tarxetas.
        cols (int): Número de columnas de tarxetas.

    Attributes:
        __game (game_window.GameWindow): Compoñente pai que contén o taboleiro (fiestra
            principal da aplicación)
        __rows (int): Número de filas de tarxetas.
        __cols (int): Número de columnas de tarxetas.
        __cards_number (int): Número de tarxetas totais que conterá o taboleiro.
        __card_positions (list):  Listado de posicións enteiras que se calculan de xeito
            aleatorio e que serán as que indiquen as posicións de cada tarxetas. O listado
            terá un tamaño igual ao número de tarxetas a colocar no taboleiro segundo o
            nivel do xogo.
        pairs_cards (list): Listado que conterá os pares de cartas a utilizar, é dicir
            elementos do tipo PairCards
    """

    def __init__(self, game, rows, cols):
        """Construtor da clase."""
        super().__init__()
        self.__rows = rows
        self.__cols = cols
        self.__cards_number = self.__rows*self.__cols
        self.__game = game
        self.__card_positions = random.sample(range(self.__cards_number), self.__cards_number)
        self.pairs_cards = []
        Options.LOG.info(self.__card_positions)

        self.setGeometry(300, 300, 700, 500)
        self.createBoard()

    def getGame(self):
        """Obtén o compoñente pai no que está o taboleiro.

        Returns:
            GameWindow: Compoñente principal da aplicación que contén o taboleiro.
        """
        return self.__game

    def createBoard(self):
        """Método encargada de xerar e inicializar todas as tarxetas que conterá o taboleiro."""
        grid_layout = QGridLayout()
        self.createPairsCards()
        i = 0
        while i < len(self.pairs_cards):
            msg_log = "Para o par co id: %s", str(self.pairs_cards[i].getId())
            Options.LOG.info(msg_log)
            row_a = self.pairs_cards[i].getCard(PairCards.CardType.A).position_number//self.__cols
            col_a = self.pairs_cards[i].getCard(PairCards.CardType.A).position_number % self.__cols
            msg_log = " - Tarxeta A na posición: " + str(self.pairs_cards[i].getCard(PairCards.CardType.A).position_number) + \
                 " => fila: " + str(row_a) + ", columna: " + str(col_a)
            Options.LOG.info(msg_log)
            row_b = self.pairs_cards[i].getCard(PairCards.CardType.B).position_number//self.__cols
            col_b = self.pairs_cards[i].getCard(PairCards.CardType.B).position_number % self.__cols
            msg_log = " - Tarxeta B na posición: " + str(self.pairs_cards[i].getCard(PairCards.CardType.B).position_number) + \
                " => fila: " + str(row_b) + ", columna: " + str(col_b)
            Options.LOG.info(msg_log)
            grid_layout.addWidget(self.pairs_cards[i].getCard(PairCards.CardType.A), row_a, col_a)
            grid_layout.addWidget(self.pairs_cards[i].getCard(PairCards.CardType.B), row_b, col_b)
            i += 1

        self.setLayout(grid_layout)
        Options.LOG.info("Finaliza createBoard")

    def createPairsCards(self):
        """Método encargada de crear os pares de tarxetas que conterá o taboleiro, de xeito que xa
        queden inicializadas para que se poidan emparellar desde o punto de vista lóxico."""
        i = 0
        cont = 1
        while (i < len(self.__card_positions)):
            Options.LOG.info("Imos pintar o par: " + str(i) + " e " + str(i+1))
            pos_card_a = self.__card_positions[i]
            pos_card_b = self.__card_positions[i+1]
            Options.LOG.info(" - A tarxeta A na posición: " + str(pos_card_a))
            Options.LOG.info(" - A tarxeta B na posición: " + str(pos_card_b))
            if (cont <= 9):
                image = "image_0"+str(cont)+".png"
            else:
                image = "image_"+str(cont)+".png"
            Options.LOG.info(type(pos_card_a))
            self.pairs_cards.append(PairCards(board=self, pos_card_a=pos_card_a, pos_card_b=pos_card_b, image=image))
            cont += 1
            i += 2
        Options.LOG.info("Finaliza createPairsCards")

    def getUnpairedPairs(self):
        """Método que devolve o número de cartas que non se atopan emparelladas, é dicir o par ao que están asignadas
        ten o estado 'pair.__paired = False' e ademais están dadas a volta CardPosition = 'FRONT'

        Returns:
            int: Número de tarxetas non emparelladas que están descubertas
        """
        cont = 0
        for pair in self.pairs_cards:
            if (pair.isPaired()):  # Si están emparelladas non facemos nada e continuamos comprobando as seguintes
                continue

            if (pair.getCard(PairCards.CardType.A).getCardPosition() != pair.getCard(PairCards.CardType.B).getCardPosition()):
                cont += 1
        return cont

    def updateBoard(self):
        """Método principal da clase encargado de actualizar o estado das tarxetas cada vez que prememos sobre unha para
        descubrila. No caso de que a súa parella se atope tamén descuberta, entón emparéllaas, actualizando o estado do
        par 'pair.__paired = True'. Esas tarxetas xa quedan descubertas e bloquedas para que non se poida facer nada
        sobre elas. En caso contrario oculta as tarxetas descubertas sen emparellar.
        """
        unpaired_pairs = self.getUnpairedPairs()
        count_attempt = False
        for pair in self.pairs_cards:
            if (pair.isPaired()):  # Si xa están emparelladas non facemos nada e continuamos comprobando as seguintes
                continue

            # Se as rematamos de atinar, entón emparellámolas e continuamos
            if (pair.getCard(PairCards.CardType.A).getCardPosition() == Card.CardPosition.FRONT and pair.getCard(PairCards.CardType.B).getCardPosition() == Card.CardPosition.FRONT):
                pair.setPaired(True)
                count_attempt = True
                self.getGame().update_pairs()
                continue
            # No caso de que non estea emparellada, nin se acabe de seleccionar (e polo tanto a emparellamos), volvemos ocultala, sempre e cando haxa
            # algunha outra nesa mesma situación. Por aquí so pasa se non cumpre ningún dos supostos anteriores
            if (unpaired_pairs > 1):
                count_attempt = True
                pair.getCard(PairCards.CardType.A).show(Card.CardPosition.REVERSE)
                pair.getCard(PairCards.CardType.B).show(Card.CardPosition.REVERSE)

        if (count_attempt):
            self.getGame().updateRemainingAttempts()
