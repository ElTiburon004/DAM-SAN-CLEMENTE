# -*- coding: utf-8 -*-
"""
Módulo que contén os elementos precisos para representar e manexar cada unha das tarxetas
que debemos emparellar no xogo.
"""
from enum import Enum
from PySide2.QtWidgets import QLabel
from PySide2 import QtCore
from PySide2.QtGui import QPixmap
from lib.options import Options

class Card(QLabel):
    """ Clase usada para representar cada unha das tarxetas da aplicación.
    Estende á clase base QLabel de Qt.

    Exemplo:
        Card(board, image, pos_number)

    Args:
        board (Board): Taboleiro sobre o que se coloca a tarxeta.
        image (str): Ruta á imaxe da tarxeta. Valor asignado a self.__image
        pos_number (int): Posición da tarxeta dentro do taboleiro.

    Attributes:
        __board (Board): Taboleiro sobre o que se coloca a tarxeta.
        __image_reverse (str): Ruta á imaxe que se amosa por defecto cando a tarxeta se atopa oculta.
        __image (str): Ruta á imaxe asignada á tarxeta.
        __card_status (CardStatus): Posición da tarxeta dentro do taboleiro.
        __card_pos (CardPosition): Posición na que se atopa a tarxeta. Por defecto ao inicio estará
            oculta CardPosition.REVERSE
    """
    
    class CardPosition(Enum):
        REVERSE = 0
        FRONT = 1

    def __init__(self, **kwargs):
        """Construtor da clase."""
        super().__init__()
        self.__image_reverse = Options.THEME + "hidden_image.png"
        self.__card_status = self.CardPosition.REVERSE
        if ("board" in kwargs):
            self.__board = kwargs["board"]
        if ("image" in kwargs):
            self.__image = Options.THEME + kwargs["image"]
        if ("pos_number" in kwargs):
            self.position_number = kwargs["pos_number"]
        else:
            raise Exception("Non se definiu a posición 'pos_number' ")
        self.show(self.CardPosition.REVERSE)


    def show(self, card_pos: CardPosition):
        """Amosa a tarxeta na posición indicada

        Args:
            card_pos (CardPosition): Posición na que desexamos amosar a tarxeta
        """
        self.__card_status = card_pos
        if (self.__card_status == self.CardPosition.FRONT):
            pixmap = QPixmap(self.__image)
        elif (self.__card_status == self.CardPosition.REVERSE):
            pixmap = QPixmap(self.__image_reverse)

        pixmap = pixmap.scaled(200, 200, QtCore.Qt.KeepAspectRatio)
        self.setPixmap(pixmap)
        self.setScaledContents(True)
        self.__card_pos = card_pos

    def getBoard(self):
        """Amosa a tarxeta na posición indicada

        Returns:
            Board: Devolve o taboleiro sobre o que se atopa a tarxeta
        """
        return self.__board

    def getCardPosition(self):
        """Devolve a posición da tarxeta

        Returns:
            Card: Devolve a carta do par indicada mediante CardType (A ou B)
        """
        return self.__card_pos

    def mousePressEvent(self, QMouseEvent):
        """Sobreescribe o evento de QLabel encargado de controlar a pulsación dos botóns do rato
        para que cando se prema sobre a tarxeta co botón esquerdo do rato, permita visualizar
        a imaxe que ten oculta. No caso de que se atope xa visualizada, non fai nada

        Args:
            QMouseEvent (PySide2.QtGui.QMouseEvent): Evento que captura a acción do rato
        """
        super().mousePressEvent(QMouseEvent)
        if QMouseEvent.buttons() == QtCore.Qt.LeftButton:  # Determine whether the left mouse button clicks
            if (self.getBoard().getUnpairedPairs() < 2):
                self.show(self.CardPosition.FRONT)
            self.getBoard().getGame().addActionToGameThread(Options.Action.UPDATE_CARDS)  # Actualizamos a través do thread para que non se quede conxelada a nosa app
