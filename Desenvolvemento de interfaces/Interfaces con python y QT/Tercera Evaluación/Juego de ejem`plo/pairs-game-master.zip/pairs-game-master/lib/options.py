# -*- coding: utf-8 -*-
"""
Este módulo contén todas as opcións xerais de configuración da aplicación.
"""
from enum import Enum
import logging
import gettext


class Options(object):
    """ Clase contén as opcións de configuración utilizadas ao longo da aplicación"""

    class Action(Enum):
        """ Clase que extende a un enumerado e define o tipo de accións permitidas no fío secundario
        da aplicación ProcessThread
        """
        UPDATE_CARDS = "UPDATE_CARDS"
        NEW_LEVEL = "NEW_LEVEL"

    __AUTHOR__ = "Manuel Pacior Pérez"
    __COPYRIGHT__ = "Copyright 2021, Pairs Game"
    __PROJECT__ = "Pairs Game"
    __LICENSE__ = "GPL"
    __VERSION__ = "0.1.0"
    __EMAIL__ = "manuelpacior@edu.xunta.gal"
    __STATUS__ = "Developer"
    __LOGO__ = "resources/logo.png"
    """Atributos xerais do proxecto"""

    LEVELS = ({"rows": 2, "cols": 3, "time": 25, "attempts": 10},
              {"rows": 3, "cols": 4, "time": 60, "attempts": 20},
              {"rows": 3, "cols": 6, "time": 75, "attempts": 25},
              {"rows": 4, "cols": 6, "time": 90, "attempts": 35},
              )
    """LEVELS (tuple): Tupla que contén un listado de diccionarios de xeito que representan
            as opcións de configuración de cada nivel do xogo, sendo o elemento '0' da tupla
            representa o nivel '1' do xogo, e así de xeito sucesivo. Para cada nivel o
            diccionario que contén terá os seguintes parámetros.
                    
            Exemplo:
                LEVELS[0]: {"rows": 2, "cols": 3, "time": 30, "attempts": 7}
                LEVELS[1]: {"rows": 3, "cols": 4, "time": 60, "attempts": 12}
                LEVELS[2]: {"rows": 3, "cols": 6, "time": 75, "attempts": 16}
                LEVELS[3]: {"rows": 4, "cols": 6, "time": 90, "attempts": 20}               

            Detalle:
                - "rows" Número de filas de tarxetas.
                - "cols" Número de columnas de tarxetas.
                - "time" Tempo máximo en segundos para resolver o xogo.
                - "attempts" Número máximo de intentos para superar o nivel.
    """

    COLORS = {"bg_main_window": "#F1F4F9",
              "bg_countdown": "#F6A48C",
              "bg_attempts": "#F9CD92",
              "bg_pairs": "#CDFBE4",
              "bg_level": "#D8CDFF",
              "lcd_font_color": "#000000",
              }
    """Diccionario que contén as diferentes opcións de cores do xogo."""

    TMP_QWIDGET_BG_COLOR = "QWidget {background-color: %s}"
    """Modelo usado para mudar a cor de fondo dun QWidget"""

    TR_ = gettext.gettext
    """Función 'gettext' Usado para manexar as traduccións da aplicación de xeito centralizado.
    Para que a detecte automaticamente pode ter calquera nome sempre que remate '_'
    """

    ICONS = {
        "new": "resources/icons/icon-new.png",
        "exit": "resources/icons/icon-exit.png",
        "manual": "resources/icons/icon-manual.png",
        "about": "resources/icons/icon-about.png",
    }

    IMAGE_THEMES = {
        "planets": "resources/images/planets/",
        "cartoons": "resources/images/cartoons/"
    }
    """Aínda que so temos as imaxes de planetas, está todo feito de xeito parametrizable, de feito
    que poderíamos engadir imaxes doutra temática e simplemente teríamos que inserilas co mesmo
    nome e do mesmo tamaño que as existentes na carpeta 'planets', pero dentro dunha carpeta
    propia co nome do novo tema (por exemplo 'cartoons')
    """

    THEME = IMAGE_THEMES["planets"]
    """Seleccionamos un dos temas de imaxes dos engadidos enriba, será o que se use (activo)"""

    LOG = logging.getLogger("PairsGame")
    """Definimos un logger global que usaremos e toda a aplicación. O logging configurámolo no Main"""

    def initLogging():
        """Método da clase Options que usamos para inicializar o logging"""
        logging.basicConfig(level=logging.DEBUG,
                            format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
                            datefmt='%m-%d %H:%M',
                            filename='logs/myapp.log')
