lib package
===========

.. automodule:: lib
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

lib.board module
----------------

.. automodule:: lib.board
   :members:
   :undoc-members:
   :show-inheritance:

lib.card module
---------------

.. automodule:: lib.card
   :members:
   :undoc-members:
   :show-inheritance:

lib.game\_window module
-----------------------

.. automodule:: lib.game_window
   :members:
   :undoc-members:
   :show-inheritance:

lib.options module
------------------

.. automodule:: lib.options
   :members:
   :undoc-members:
   :show-inheritance:

lib.other\_windows module
-------------------------

.. automodule:: lib.other_windows
   :members:
   :undoc-members:
   :show-inheritance:

lib.pair\_cards module
----------------------

.. automodule:: lib.pair_cards
   :members:
   :undoc-members:
   :show-inheritance:

lib.process\_thread module
--------------------------

.. automodule:: lib.process_thread
   :members:
   :undoc-members:
   :show-inheritance:
