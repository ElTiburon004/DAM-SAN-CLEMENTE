.. Pairs Game documentation master file, created by
   sphinx-quickstart on Sun Apr  4 00:10:58 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Benvido á documentación do Xogo de parellas!
============================================

.. toctree::
   :maxdepth: 2
   :caption: Contidos:
   
   README
   api/modules
   api/lib
   api/main


Índices e táboas
================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`