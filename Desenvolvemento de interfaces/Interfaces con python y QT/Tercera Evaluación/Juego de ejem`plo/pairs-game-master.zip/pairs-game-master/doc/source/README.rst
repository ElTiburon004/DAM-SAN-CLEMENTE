Xogo das parellas
=================

.. figure:: pairs_game.png
   :alt: Imaxe do xogo

Recursos
--------

-  Guía para a sintaxe mardown:

   -  https://spines.me/es/help/markdown/syntax/
   -  https://www.markdownguide.org/getting-started/

-  PySide2 (Qt 5 sobre Python):
   https://doc.qt.io/qtforpython-5/contents.html

-  Variables de configuración:
   https://code.visualstudio.com/docs/editor/variables-reference

-  Documentación de proxectos Python con Sphinx:
   https://www.sphinx-doc.org/en/master/

-  Sistema de logs en Python:
   https://docs.python.org/es/3/howto/logging.html


Preparar Visual Studio Code
---------------------------

-  Instalar o plugin “VSC Extension Export & Import \| VSC-Export”:

   -  https://marketplace.visualstudio.com/items?itemName=aslamanver.vsc-export

   -  Usaremos este engadido para importar a copia de todos os plugins
      de VSCode precisos para que traballe con Python, PyQt e depurar
      esa linguaxe

   -  Unha vez instalado debemos importar o listado de plugins que
      desexamos instalar. Trátase do ficheiro “vsc-extensions.txt” que
      está no raíz do proxecto. (Ollo!, ten que estar nesa ubicación)

   -  Importar os plugins de VSCode precisos para a súa instalación:

-  Para proceder á importación tan so temos que premer a combinación de
   teclas “Ctrl+Insert+P” e no campo de texto superior buscamos a opción
   “VSC Extensions Import”, seleccionámola e automaticamente nos
   instalará todos os plugins que aparecen listados en
   “vsc-extensions.txt”

-  Cando rematemos de instalar os plugins do VSCode, podemos eliminar o
   ficheiro vsc-extensions.txt

Instalar as dependencias do sistema
-----------------------------------

Será preciso instalar as dependencias que se indican a continuación, xa
que se usarán para poder executar a aplicación:

::

   ```
   # Este script serve para instalar todos os paquetes necesarios para montar a nosa contorna
   sudo apt-get install python3 python3-pip 
   sudo apt-get install python-virtualenv virtualenv
   sudo pip install --upgrade autopep8
   ```

Xerar a contorna virtual
------------------------
Para poder executar a aplicación debemos instalar as dependencias python necesarias, podemos facelo 
directamente sobre o noso sistema, se ben recomendo usar unha contorna de execución virtual.

.. note::

   Unha contorna de execución virtual en Python, permitirá configurar por
   defecto unha versión determinada de Python das instaladas no sistema que
   poderá manexar un conxunto de librarías Python que son descargadas e
   usadas de xeito exclusivo na contorna creada:

      -  Facilitar a xestión e resolución de paquetes
      -  Dota de máis control e seguridade o desenvolvemento de aplicacións
      -  Permite que convivan en contornas diferentes, versións dispares da
         mesma libraría ou recurso.


Debemos seguir os seguintes pasos:

1. Entramos na carpeta do noso proxecto (substitue ruta_ao_proxecto pola
   do teu proxecto): ``$ cd ruta_ao_proxecto``

2. Unha vez dentro crearemos unha contorna virtual para a execución de
   Python (podemos substituír “.env” polo nome que lle desexemos dar,
   normalente uso este por convenio)
   ``$ virtualenv --python=python3 .env``

3. Para habilitar a contorna de execución temos que indicalo deste xeito
   ``$ source .env/bin/activate``

4. A partires dese momento estamos traballando coa contorna creada para
   este proxecto en particular. Agora aparecerá o nome ``(.env)`` diante
   do símbolo do sistema no terminal. Iso indica que está onde queremos.

5. Instalamos os paquetes precisos e que se atopan no ficheiro
   requirements.txt executando:
   ``$ pip install -r conf/requirements.txt``

6. Se nalgún momento instalamos máis paquetes de python e queremos
   actualizar o listado que está en ‘requirements.txt’ para que engada
   os paquetes que instalamos faremos:
   ``$ pip freeze > requirements.txt``

Pode que nalgún momento nos xurda a necesidade de limpar os ficheiro
“precompilados” (extensión .pyc). Para facelo de xeito recursivo desde
Linux podemos executar:
``$ find . | grep -E "(__pycache__|\.pyc|\.pyo$)" | xargs rm -rf``

Executar a aplicación
---------------------

Unha vez que temos a nosa contorna virtual creada e cos paquetes
necesarios instalados, xa podemos executar a aplicación baixo a mesma.
Para iso so temos que facer o seguinte:

1. Habilitamos a contorna:``$ source .env/bin/activate``
2. Executamos a aplicación: ``$ python main.py``

Agora calquera aplicación python que executemos farao baixo a contorna
virtual. Para saír da mesma tan so temos que facer: ``$ deactivate``

Xerar a documentación
---------------------
A continuación indicamos os pasos necesarios para xerar a documentación:

1. Situámonos na carpeta doc: 
   ``$ cd doc``
2. Xerarmos os documentos ReStructuredText da API a partires do noso código fonte: 
   ``$ sphinx-apidoc -f -M -o source/api/ ../lib/game/``
3. Xeramos a nosa documentación: 
   Formato HTML: ``$ make html``
   Formato PDF: ``$ make latexpdf``
   
   Pode que en ocasións sexa preciso partir de cero á hora de xerar a documentación
   se así fora debemos executar: ``$ make clean``