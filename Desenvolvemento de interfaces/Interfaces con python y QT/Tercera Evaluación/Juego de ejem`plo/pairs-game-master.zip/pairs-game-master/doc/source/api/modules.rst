pairs-game
==========

.. toctree::
   :maxdepth: 4

   lib
   main
