# -*- coding: utf-8 -*-
"""
Módulo principal da aplicación, encargado de inicializar a súa execución
"""
import sys
import logging
from PySide2.QtWidgets import QApplication
from lib.game_window import GameWindow
from lib.options import Options


def runApp():
    """Función principal que lanza a execución da nosa aplicación, concretamente realiza as 
    seguintes accións:
     
    - Options.initLogging(): Configuramos o sistema de logging da aplicación, entre outras cousas indicamos 
      so ficheiro no que se gardan os logs, o formato da mensaxe e o nivel de logs
 
    - app = QApplication(sys.argv): Comezamos definindo a instancia da aplicación principal Qt e pasamos
      a lista de argumentos do sistema.

    - pairGame = GameWindow(): Creamos a nosa aplicación principal, que no seu constructor xa se inicializa
      e se amosa de xeito automático.

    - sys.exit(app.exec_()): Inicia o ciclo de eventos até que se pecha a aplicación.
    """

    Options.initLogging()
    """Configuramos o sistema de logging da aplicación, entre outras cousas indicamos
    o ficheiro no que se gardan os logs, o formato da mensaxe e o nivel de logs"""

    app = QApplication(sys.argv)
    """Comezamos definindo a instancia da aplicación principal Qt e pasamos 
    a lista de argumentos do sistema."""

    pairGame = GameWindow()
    """ Creamos a nosa aplicación principal, que no seu constructor xa se inicializa
    e se amosa de xeito automático"""

    sys.exit(app.exec_())
    """Inicia o ciclo de eventos até que se pecha a aplicación"""


if __name__ == "__main__":
    """Usamos o main para comprobar que realmente estamos executando o módulo directamente
    e non facendo unha importación do mesmo. En caso de que sexa así, executa a función 
    que inicializa a aplicación"""
    runApp()
   
