/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio_1;
import java.io.*;
/**
 *
 * @author samuel
 */
public class Ejercicio_1 {
        public static void main(String[] args) {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);
        String carpeta="";
        System.out.println("Introduce la ruta de la carpeta a borrar");
        
        
            try {
                carpeta = br.readLine();
            } catch (IOException ex) {
                
            }
            
        
            borrar(new File(carpeta));
    }
    
    public static void borrar(File file) {
     
        if (!file.exists())
            return;
       
        if (file.isDirectory()) {
            for (File f : file.listFiles()) {
                borrar(f);
            }
        }
        file.delete();
        System.out.println("Carpeta borrada : "+file.getAbsolutePath());
    }
}
