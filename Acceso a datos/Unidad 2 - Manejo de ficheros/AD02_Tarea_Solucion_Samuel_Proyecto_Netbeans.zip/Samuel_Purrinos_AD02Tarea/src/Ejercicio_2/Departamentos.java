/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio_2;

import java.io.Serializable;

/**
 *
 * @author samuel
 */
public class Departamentos implements Serializable {
    
    int numDep;
    String nombre;
    String localidad;
    
    public Departamentos(int numDep, String nombre, String localidad){
        
        this.numDep=numDep;
        this.nombre=nombre;
        this.localidad=localidad;
        
    }
   
    public int getNumDep(){
        return numDep;
    }
    
    public String getNombre(){
    return nombre;
}
    
    public String getLocalidad(){
        return localidad;
    }
    
    public String toString(){
        return "Número : " +numDep+ ", Nombre : "+nombre+ ", Localidad : "+localidad;
    }
}
