/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio_2;

import java.io.*;
import java.util.*;

/**
 *
 * @author samuel
 */
public class Ejercicio_2 {
    
    public static void main(String[] args) throws Exception {
         List<Departamentos> dep = new ArrayList<Departamentos>();
         
         dep.add(new Departamentos(1,"RRHH","Santiago"));
         dep.add(new Departamentos(2,"Contabilidad","A Coruña"));
         dep.add(new Departamentos(3, "Jefatura", "Lugo"));
         dep.add(new Departamentos(4,"Administración","Vigo"));
         
        try {
            FileOutputStream fos = new FileOutputStream("Departamentos.dat"); 
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(dep);
            oos.close();
        }catch (IOException e){
                e.printStackTrace();
                }
        }
    }
    
