/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio_4;
import Ejercicio_2.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author samuel
 */
public class ListaDepart {
    List<Departamentos> Depar = new ArrayList<Departamentos>();
    
    public ListaDepart(){
        
    }
     
    public void anadir(Departamentos D){
        Depar.add(D);
    }
    
    public List<Departamentos> getDepartamentos(){
        return Depar;
    } 
}
