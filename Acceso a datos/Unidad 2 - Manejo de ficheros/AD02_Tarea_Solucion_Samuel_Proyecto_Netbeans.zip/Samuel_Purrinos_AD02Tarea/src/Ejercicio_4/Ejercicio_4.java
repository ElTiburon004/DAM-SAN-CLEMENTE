/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio_4;
import Ejercicio_2.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;
import org.kxml2.io.*;
import com.thoughtworks.xstream.*;
/**
 *
 * @author samuel
 */
public class Ejercicio_4 {
    public static void main (String[] args){
         FileInputStream fis = null;
         ListaDepart lista = new ListaDepart();
        List<Departamentos> dep = new ArrayList<Departamentos>();
        try {
            fis = new FileInputStream("Departamentos.dat");
        } 
        catch (FileNotFoundException ex) {
            System.out.println("Archivo no encontrado");
        } 
          
        try {
            ObjectInputStream ois = new ObjectInputStream(fis);
            dep=(List)ois.readObject();         
        ois.close();
          
        
        } catch (IOException | ClassNotFoundException ex) {
            ex.printStackTrace();
        }
           
         for(Departamentos Depa : dep){
             lista.anadir(Depa);
         }
      
        try{
            XStream xstream = new XStream(); 
            xstream.alias("Departamento", Departamentos.class);
            xstream.aliasField("nombre", Departamentos.class, "nombre");
            xstream.alias("Listadepartamentos", ListaDepart.class);
            xstream.addImplicitCollection(ListaDepart.class, "Depar");
            xstream.toXML(lista,(new FileOutputStream("departamentos.xml")));
        }catch (Exception e){
            e.printStackTrace();
        }
        
      
        
    }
}
