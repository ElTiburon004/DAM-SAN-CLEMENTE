/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio_3;

import Ejercicio_2.*;
import java.util.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author samuel
 */
public class Ejercicio_3 {
    
    public static void main (String[] args ){
         
        FileInputStream fis = null;
        ArrayList<Departamentos> dep = new ArrayList<Departamentos>();
        try {
            fis = new FileInputStream("Departamentos.dat");
        } 
        catch (FileNotFoundException ex) {
            System.out.println("Archivo no encontrado");
        } 
          
        try {
            ObjectInputStream ois = new ObjectInputStream(fis);
            dep=(ArrayList) ois.readObject();
            ois.close();
            fis.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
           ex.printStackTrace();
        }
        
     System.out.println("Número de departamentos : "+dep.size());
       
        Scanner teclado = new Scanner(System.in);
        int numero;
        System.out.println("Introduzca el número de departamento que desea borrar");
            numero=teclado.nextInt();
       
          if(numero <0 || numero > dep.size()){
              System.out.println("El departamento no existe");
          }  else {
            try {
            for(Departamentos Depa : dep){
           if(Depa.getNumDep()==numero){
               dep.remove(Depa);
               System.out.println("El departamento ha sido borrado correctamente");
               System.out.println("Ahora el número de departamentos es : "+dep.size());
           }
       }
            }catch (Exception e){
                
            }
          }
        try {
            FileOutputStream fos = new FileOutputStream("Departamentos.dat"); 
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(dep);
            oos.close();
        }catch (IOException e){
          
                }
        
    
        }
    }
    

