package baseDatos;

import java.io.Serializable;

import javax.persistence.*;

@Entity
public class Producto implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id @GeneratedValue
	private Integer id;
	private String nombreProducto;
	private String descripcion;
	private String foto;
	private float precio;
	
	public Producto(String nombreProducto, String descripcion, String foto, float precio) {
		this.nombreProducto = nombreProducto;
		this.descripcion = descripcion;
		this.foto = foto;
		this.precio = precio;
	}

	public Integer getId() {
		return id;
	}

	public String getNombreProducto() {
		return nombreProducto;
	}

	public void setNombreProducto(String nombreProducto) {
		this.nombreProducto = nombreProducto;
	}

	public String getDescricion() {
		return descripcion;
	}

	public void setDescricion(String descricion) {
		this.descripcion = descricion;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrezo(float precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Produto [id=" + id + ", nombreProducto=" + nombreProducto + ", descripcion=" + descripcion + ", foto=" + foto
				+ ", precio=" + precio + "]";
	}
	
}
