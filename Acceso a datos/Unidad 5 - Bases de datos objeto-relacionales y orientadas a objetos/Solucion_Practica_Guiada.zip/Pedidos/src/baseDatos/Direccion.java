package baseDatos;

import javax.persistence.*;


@Embeddable //Con esta anotación, indicamos que la clase puede ser "integrable" dentro de una entidad
public class Direccion {
        @Column(name = "descripcion", length=200, nullable = false)
	private String descripcion;
        
        @Column(name = "calle", length=100, nullable = false)
	private String calle;
        
        
	private int numero;
	private String CP;
	private String ciudad;
	private String provincia;
	
	public Direccion(String descripcion, String calle, int numero, String cP, String ciudad, String provincia) {
		this.descripcion = descripcion;
		this.calle = calle;
		this.numero = numero;
		CP = cP;
		this.ciudad = ciudad;
		this.provincia = provincia;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getCalle() {
		return calle;
	}

	public void setCalle(String calle) {
		this.calle = calle;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getCP() {
		return CP;
	}

	public void setCP(String cP) {
		CP = cP;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	@Override
	public String toString() {
		return "Direccion [descripcion=" + descripcion + ", calle=" + calle + ", numero=" + numero + ", CP=" + CP + ", ciudad="
				+ ciudad + ", provincia=" + provincia + "]";
	}
}
