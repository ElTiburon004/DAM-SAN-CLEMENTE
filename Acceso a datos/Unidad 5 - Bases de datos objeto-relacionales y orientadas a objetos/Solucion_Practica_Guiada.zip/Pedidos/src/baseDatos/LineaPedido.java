package baseDatos;

import javax.persistence.*;

@Embeddable
public class LineaPedido {
	private Producto producto;
	private Float cantidad;
	private float precioTotal;
	
	public LineaPedido(Producto producto, float cantidad) {
		this.producto = producto;
		this.cantidad = cantidad;
		setPrecioTotal();
	}

	public Producto getProducto() {
		return producto;
	}

	public void setProducto(Producto producto) {
		this.producto = producto;
		setPrecioTotal();
	}

	public Float getCantidad() {
		return cantidad;
	}

	public void setCantidad(Float cantidad) {
		this.cantidad = cantidad;
		setPrecioTotal();
	}

	public float getPrecioTotal() {
		return precioTotal;
	}
	
	private void setPrecioTotal() {
		this.precioTotal = producto.getPrecio() * this.cantidad;
	}

	@Override
	public String toString() {
		return "LineaPedido [producto=" + producto + ", cantidad=" + cantidad + ", precioTotal=" + precioTotal + "]";
	}
}
