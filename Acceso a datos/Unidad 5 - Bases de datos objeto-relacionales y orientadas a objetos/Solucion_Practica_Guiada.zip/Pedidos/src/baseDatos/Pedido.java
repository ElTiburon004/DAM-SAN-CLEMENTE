package baseDatos;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

@Entity
public class Pedido implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id @GeneratedValue
	private int id;
	private Date data;
	private Cliente cliente;
	@Embedded
	private List<LineaPedido> lineasPedido;
	private float importe;
	private boolean entregado;
	
	public Pedido(Date data, Cliente cliente, List<LineaPedido> lineasPedido) {
		super();
		this.data = data;
		this.cliente = cliente;
		this.lineasPedido = lineasPedido;
		setImporte();
		this.entregado = false;
	}

	public int getId() {
		return id;
	}

	public Date getData() {
		return data;
	}
	
	private void setData(Date data) {
		this.data = data;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public List<LineaPedido> getLineasPedido() {
		return lineasPedido;
	}

	public void addLineaPedido(LineaPedido lineaPedido) {
		this.lineasPedido.add(lineaPedido);
		setImporte();
		setData(new Date());
	}

	public float getImporte() {
		return importe;
	}

	private void setImporte() {
		this.importe = 0;
		for (LineaPedido pedido : lineasPedido) {
			this.importe += pedido.getPrecioTotal();
		}	
	}

	public boolean isEntregado() {
		return entregado;
	}

	public void setEntregado(boolean entregado) {
		this.entregado = entregado;
	}

	@Override
	public String toString() {
		return "Pedido [id=" + id + ", data=" + data + ", cliente=" + cliente + ", lineasPedido=" + lineasPedido
				+ ", importe=" + importe + ", entregado=" + entregado + "]";
	}	
}
