package baseDatos;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Operacions {
	private EntityManagerFactory emf;
	private EntityManager em;
	
	private String mensajes;
	
	public String getMensajes() {
		return mensajes;
	}

	public void abrirConexion() throws Exception {
		if (emf == null && em == null) {
			emf = Persistence.createEntityManagerFactory("objectdb:prestamos.tmp;drop"); // Po�endo .tmp en lugar de .odb e engadindo ;drop, b�rrase a bd de cada vez
			em = emf.createEntityManager();
		}
	}
	
	public void cerrarConexion() throws Exception {
		if (em != null && emf != null) {
			em.close();
			emf.close();
		}
	}
	
	public void anadirProducto(Producto producto) throws Exception {
		em.getTransaction().begin();
		em.persist(producto);
		em.getTransaction().commit();
	}
	
	public Producto buscarProducto(Integer id) {
		Producto producto = null;
		
		String queryString = "select p from Producto p where p.id = ?1";
        TypedQuery<Producto> query1 = em.createQuery(queryString, Producto.class);
        query1.setParameter(1,id);
        producto = query1.getSingleResult();
        
        return producto;
	}
	
	public void anadirCliente(Cliente cliente) throws Exception {
		em.getTransaction().begin();
		em.persist(cliente);
		em.getTransaction().commit();
	}
	
	public Cliente buscarCliente(String dni) {
		Cliente cliente = null;
		
		String queryString = "select c from Cliente c where c.dni = ?1";
        TypedQuery<Cliente> query1 = em.createQuery(queryString, Cliente.class);
        query1.setParameter(1,dni);
        cliente = query1.getSingleResult();
		
		return cliente;
	}
	
	public Pedido buscarPedido(Integer id) {
		Pedido pedido = null;
		
		String queryString = "select p from Pedido p where p.id = ?1";
        TypedQuery<Pedido> query1 = em.createQuery(queryString, Pedido.class);
        query1.setParameter(1,id);
        pedido = query1.getSingleResult();
        
        return pedido;
	}
	
	public void anadirLineaPedido(Integer id, Integer codProducto, Float cantidad) {
		Pedido pedido;
		Producto producto;
		
		producto = buscarProducto(codProducto);
		pedido = buscarPedido(id);
		
		if (!pedido.isEntregado()) {
			pedido.addLineaPedido(new LineaPedido(producto, cantidad));
			
			em.getTransaction().begin();
			em.persist(pedido);
			em.getTransaction().commit();
		}
	}
	
	public void borrarPedido(Integer id) {
		Pedido pedido;
		
		pedido = buscarPedido(id);
		
		em.getTransaction().begin();
		em.remove(pedido);
		em.getTransaction().commit();
	}
	
	public void entregarPedido(Integer id) {
		Pedido pedido;
		
		pedido = buscarPedido(id);
        
        pedido.setEntregado(true);
        
		em.getTransaction().begin();
		em.persist(pedido);
		em.getTransaction().commit();
	}
	
	public List<Pedido> listadoPedidos() throws Exception {
		List<Pedido> pedidos = new ArrayList<>();
		
		String queryString = "select p from Pedido p";
		TypedQuery<Pedido> query = em.createQuery(queryString, Pedido.class);
		pedidos = query.getResultList();
		
		return pedidos;
	}
	
	public void anadirPedido(String dni, List<Integer> codigosProducto, List<Float> cantidades) throws Exception {
		Pedido pedido = null;
		
		Cliente cliente = buscarCliente(dni);
		
		List<Producto> productos = new ArrayList<>();
		for (Integer codigo : codigosProducto) {
			productos.add(buscarProducto(codigo));
		}
		
		List<LineaPedido> lineasPedido = new ArrayList<>();
		for (int i = 0; i < cantidades.size(); i++) {
			lineasPedido.add(new LineaPedido(productos.get(i), cantidades.get(i)));
		}
		
		pedido = new Pedido(new Date(), cliente, lineasPedido);
		
		em.getTransaction().begin();
		em.persist(pedido);
		em.getTransaction().commit();
	}
}
