package baseDatos;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity //Anotacion para indicarle JPA que esta CLASS es una ENTIDAD
@Table(name = "clientes") //Anotación para indicar que esta clase mapea contra la table CLIENTES. Es opcional.
public class Cliente implements Serializable {
	private static final long serialVersionUID = 1L;
	
	
	@Id //Anotación para indicar que el campo 'dni' es la clave primaria. Es opcional.
        @Column(name = "dni") // Anotación para indicar que el campo 'dni' va a ser persistido en la columna 'dni'
        private String dni;
        
        @Column(name = "nombre", length=20, nullable = false)
       	private String nombre;
        
        @Column(name = "apellidos", length=50, nullable = false)
	private String apellidos;
        
        /*
        Con esta anotación, indicamos que el campo o la propiedad de una entidad
        es una instancia de una clase que puede ser integrable. Para que funcione, 
        el campo que hayamos anotado como @Embedded, debe corresponderse con una
        clase que tenga la anotación @Embeddable
        */
	@Embedded
	private Direccion direccion;
	private List<String> telefonos;
	private String correoe;
	
	public Cliente(String dni, String nombre, String apellidos, Direccion direccion, List<String> telefonos,
			String correoe) {
		this.dni = dni;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.direccion = direccion;
		this.telefonos = telefonos;
		this.correoe = correoe;
	}

	public String getDni() {
		return dni;
	}
	
	public void setDni(String dni) {
		this.dni = dni;
	}
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public Direccion getDireccion() {
		return direccion;
	}

	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}

	public List<String> getTelefonos() {
		return telefonos;
	}

	public void setTelefonos(List<String> telefonos) {
		this.telefonos = telefonos;
	}

	public String getCorreoe() {
		return correoe;
	}

	public void setCorreoe(String correoe) {
		this.correoe = correoe;
	}

	@Override
	public String toString() {
		return "Usuario [dni=" + dni + ", nombre=" + nombre + ", apellidos=" + apellidos + ", direccion=" + direccion
				+ ", telefonos=" + telefonos + ", correoe=" + correoe + "]";
	}
}
