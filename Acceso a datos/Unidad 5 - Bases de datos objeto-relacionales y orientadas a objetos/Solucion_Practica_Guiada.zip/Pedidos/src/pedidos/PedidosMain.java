package pedidos;

import java.util.ArrayList;
import java.util.List;

import baseDatos.*;

public class PedidosMain {

	public static void main(String[] args) {
		try {
			Operacions op = new Operacions();
			
			op.abrirConexion();
			
			Direccion direccion1 = new Direccion("Domicilio principal", "Rua da Oliveira", 3, "767646", "Monforte de Lemos", "Lugo");
			Direccion direccion2 = new Direccion("Segunda residencia", "Lugar de Toxosoutos", 14, "33884", "Viana do Bolo", "Ourense");
			List<String> telefonos1 = new ArrayList<String>();
			telefonos1.add("988473637");
			telefonos1.add("765456348");
			List<String> telefonos2 = new ArrayList<String>();
			telefonos2.add("976636473");
			Cliente cliente1 = new Cliente("48477488E", "Romualdo", "Fernandez Perez", direccion1, telefonos1, "r.fernandez@gmail.com");
			Cliente cliente2 = new Cliente("234443334U", "Frederico", "Lobishome", direccion2, telefonos2, "lobito@gmail.com");
			
			Producto producto1 = new Producto("Cola Cao", "Cola Cao Original 800 gr.", "colacao.jpg", 4.4F);
			Producto producto2 = new Producto("Caramelos Sugus", "Caramelos Sugus varios sabores", "sugus.jpg", 0.05F);
			Producto producto3 = new Producto("Leche Feiraco", "Leche Feiraco Semidesnatada", "feiraco.jpg", .56F);
			Producto producto4 = new Producto("Caviar Franchute", "Caviar L'Esturgeon 120 gr.", "caviar.jpg", 123F);
			
			op.anadirCliente(cliente1);
			op.anadirCliente(cliente2);
			
			op.anadirProducto(producto1);
			op.anadirProducto(producto2);
			op.anadirProducto(producto3);
			op.anadirProducto(producto4);
			
			List<Integer> codProducto1 = new ArrayList<>();
			codProducto1.add(producto1.getId());
			codProducto1.add(producto4.getId());
			List<Integer> codProducto2 = new ArrayList<>();
			codProducto2.add(producto1.getId());
			codProducto2.add(producto2.getId());
			codProducto2.add(producto3.getId());
			
			List<Float> cantProduto1 = new ArrayList<>();
			cantProduto1.add(2F);
			cantProduto1.add(23F);
			List<Float> cantProduto2 = new ArrayList<>();
			cantProduto2.add(1F);
			cantProduto2.add(245F);
			cantProduto2.add(6F);
			
			op.anadirPedido(cliente1.getDni(), codProducto1, cantProduto1);
			op.anadirPedido(cliente2.getDni(), codProducto2, cantProduto2);
			
			mostrarPedidos(op);
			
			op.entregarPedido(5);
			
			op.borrarPedido(5);
			
			Thread.sleep(2000);

			op.anadirLineaPedido(6, 4, 3.5F);
			
			mostrarPedidos(op);
			
			op.cerrarConexion();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void mostrarPedidos(Operacions op) {
		try {
			List<Pedido> pedidos = op.listadoPedidos();
			
			for (Pedido pedido : pedidos) {
				System.out.println(">>>>>>>>>> PEDIDO " + pedido.getId() + " >>>>>>>>> FECHA: " + pedido.getData());
				System.out.println("\nCLIENTE: " + pedido.getCliente().getNombre()+ " " + pedido.getCliente().getApellidos()+
				"\tIMPORTE TOTAL: " + pedido.getImporte() + "€\n");
				
				System.out.println("PRODUCTO\t\t\t\t\tCANT\tPRECIO");
				for (LineaPedido lp : pedido.getLineasPedido()) {
					System.out.println(lp.getProducto().getDescricion() + "\t\t" + lp.getCantidad() + "\t" + lp.getPrecioTotal()+ "€");
				}
				System.out.println("\n----------------------------------------------------------------------\n");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
