/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;

/**
 *
 * @author samuel
 */
public class Ejercicio_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("Introduce un número y te diré si es cuadrado de dos enteros");
        Scanner teclado = new Scanner(System.in);
        double x, y;
        
        x=teclado.nextDouble();
        
        System.out.println("Número entero "+x);
        
        if(Math.sqrt(x)*Math.sqrt(x)==x){
            System.out.println("El "+x+" se puede expresar como el cuadrado de "+Math.sqrt(x));
        }else{
            System.out.println("El "+x+" no se puede expresar como el cuadrado de ningún número entero");
        }
    }
    
}
