/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TallerSamuel;

import java.util.regex.*;

/**
 *
 * @author samuel
 * Esta clase se encarga de validar los datos leídos del teclado en la clase PideDatos
 */
public class Validaciones {
    
    
    // Valida mediante una expresión regular el formato del DNI
     //en caso de que el formato coincida con el establecido en la expresión regular, devuelve true
    //en cualquier otro caso devuelve false
    
    public boolean validaDNI(String DNI){
        
        Pattern patron = Pattern.compile("[0-9]{8}[A-Za-z]");
        
        Matcher m = patron.matcher(DNI);
        
        if(m.matches())return true;
        
        else return false;
        
    }
    
    
    //valida mediante una expresión regular el formato de la matrícula
    //en caso de que el formato coincida con el establecido en la expresión regular, devuelve true
    //en cualquier otro caso devuelve false
    
    public boolean validaMatricula(String matricula){
        
        Pattern patron = Pattern.compile("[0-9]{4}[A-Z]{3}");
        
        Matcher m =patron.matcher(matricula);
        
        if (m.matches()) return true;
        
                else return false;
        
    }
    
    //Comprueba que en la variable de tipo String pasada por parámetro existan dos espacios en blanco
    //si existen dos espacios en blanco, devuelve true, en cualquier otro caso devuelve false
    
    public boolean validaNombre(String nombre){
        
        int espacios=0;
        
       for (int i=0; i<nombre.trim().length();i++){
           
           if(nombre.charAt(i)== ' ') espacios++;
                 
       }
        
        if(espacios==2)return true;
        
        else return false;
    }
    
    
    }
    