/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TallerSamuel;

import java.time.LocalDate;
import static java.time.temporal.ChronoUnit.YEARS;

/**
 *
 * @author samuel
 */
public class Vehiculo {
    
    //Constructor, asigna valores a los atributos
    
    public Vehiculo(String nombrePropietario, String DNI, String marca, int km, int dia, int mes, int anio, String reparacion, String matricula){
        
        this.nombrePropietario=nombrePropietario;
        
        this.DNI=DNI;
        
        this.marca=marca;
        
        this.reparacion=reparacion;
        
        fechaMatricula= LocalDate.of(anio,mes,dia);
        
        kilometros=km;
        
        this.matricula=matricula;
    }
    
 
    //Métodos getter para recuperar el valor de las variables
    
    public String getMatricula(){
        return matricula;
    }
    
    public int getKilometros(){
        return kilometros;
    }
    
    public String getNombrePropietario(){
        return nombrePropietario;
    }
    
    public String getDNI(){
        return DNI;
    }
    
    public String getReparacion(){
        return reparacion;
    }
    
    public Double getImporteFactura(){
        return importeFactura;
    }
    
    // devuelve la diferencia en años entre la fecha actual y la la fecha asignada al atributo de clase de tipo LocalDate
    
    public long getAniosVehiculo(){
        
        LocalDate fechaActual = LocalDate.now();
        
        return YEARS.between(fechaMatricula, fechaActual);
        
    }
    
    
    //Métodos setter para asignar un valor a los atributos kilometros e importeFactura
    
    public void setKilometros(int km){
        kilometros=km;    
    }
    
    public void setImporteFactura(Double importe){
        importeFactura=importe;
    }
    
    public String toString(){
        
        return "Matricula : "+matricula+", Marca : "+marca+", KM : "+kilometros+", Propietario : "+nombrePropietario;
    }
    
    private int kilometros;
    
    private String nombrePropietario;
    
    private String matricula;
    
    private int diaMatricula;
    
    private int mesMatricula;
    
    private int anioMatricula;
    
    private LocalDate fechaMatricula;
    
    private String marca;
    
    private String reparacion;
    
    private String DNI;
    
    private Double importeFactura;
}

