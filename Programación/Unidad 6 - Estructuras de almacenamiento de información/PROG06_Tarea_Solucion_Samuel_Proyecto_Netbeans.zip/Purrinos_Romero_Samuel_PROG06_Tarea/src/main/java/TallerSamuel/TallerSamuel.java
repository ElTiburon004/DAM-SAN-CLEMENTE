/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TallerSamuel;


/**
 *
 * @author samuel
 * esta clase se encarga de realizar operaciones con el array de objetos tipo Vehiculo
 */
public class TallerSamuel {
    
    //este método recorre el array tallerSamuel e inserta un objeto vehículo en caso de que no haya un objeto con el mismo valor en el
    //atributo matrícula que el pasado por parámtro, devolviendo un 0. En caso de que la matrícula dada ya esté presente en el array, devuelve un - 2
    // En el resto de casos devuelve 0

       public int insertaVehiculo(Vehiculo nuevoCoche){
           
           for (int i = 0; i< tallerSamuel.length; i++){
               
               if(tallerSamuel[i] != null && tallerSamuel[i].getMatricula().equals(nuevoCoche.getMatricula())){
                   
                  System.out.println("Error. Ya existe un coche con esa matrícula");
                   
                   return -2;
                   
               }
               
               if (tallerSamuel[i]==null){
                   
                   tallerSamuel[i]=nuevoCoche;
                   
                   System.out.println("Vehiculo guardado correctamente\n");
                   
                   return 0;
                   
               }
               
           }
           
           return -1;
       }
       

   
// Recorre el array tallerSamuel y muestra los datos de los objetos vehículo contenidos en el array. En caso de estar vacío, sale del bucle
//con la sentencia return
   
   public void listarVehiculos(){
       for(int i =0; i< tallerSamuel.length;i++){
           if(tallerSamuel[i] !=null){
               System.out.println(tallerSamuel[i].toString());
           }else return;
       }
   }
   
//recorre el array tallerSamuel y si encuentra un atributo matrícula que coincida con el pasado por parámetro, actaliza los kilómetros pasados
//por parámetro en el objeto Vehiculo del array, devolviendo true al finalizar. En el resto de los casos, devuelve false
   
   
   public boolean actualizaKms(String matricul, int kms){
       
       for (Vehiculo v : tallerSamuel){
           if (matricul.equals(v.getMatricula())){
               v.setKilometros(kms);
               return true;
           
       }
       }
       return false;
   }
   
   //recorre el array tallerSamuel y compara la matricula pasada por parámetro con el atributo matricula de los objetos vehiculo del array.
   //en caso de coincidencia, devuelve un string con los datos del objeto y en todos los demás casos devuelve null
   
   public String buscaVehiculo(String matricula){
       
       for (int i =0;i< tallerSamuel.length;i++){
           if(tallerSamuel[i].getMatricula().equals(matricula)) {return tallerSamuel[i].toString();}
           
       }
       
       return null;
   }
   
   
   //recorre el array tallerSamuel y si encuentra un objeto vehículo con la misma matrícula que la pasada por parámetro, borra el objeto y devuelve true
   //en caso de no encontrar la matrícula, devuelve false
   
   public boolean eliminaVehiculo(String matricula){
       
      for (int i = 0; i<tallerSamuel.length;i++){
          
          if(tallerSamuel[i] != null && tallerSamuel[i].getMatricula().equals(matricula)){
              
             tallerSamuel[i]=null;
             
             return true;
             
          }
          
      }
      
      return false;
   }

   
   //crea un array de tipo vehiculos con un tamaño de 50
   
   private Vehiculo[] tallerSamuel = new Vehiculo[50];
   
 
   
  
}