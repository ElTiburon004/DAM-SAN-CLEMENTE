/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TallerSamuel;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

/**
 *
 * @author samuel
 * Esta clase muestra el menú por pantalla, lee del teclado los datos necesarios para construir el objeto vehículo y los
 * datos para realizar las acciones propuestas en la tarea.
 */
public class PideDatos {
    
    //muestra el menú de la apliación por pantalla y llama a los métodos que realizan las acciones descritas
    
     public void menu(){
        
        //Muestra las opciones del menú
        
        System.out.println("Por favor, introduzca el número de acción que desea realizar y presione intro\n");
        System.out.println("1. Nuevo vehículo");
        System.out.println("2. Listar vehículos");
        System.out.println("3. Buscar vehículo");
        System.out.println("4. Modificar kms vehículo");
        System.out.println("5. Eliminar vehículo");
        System.out.println("6. Salir\n");
        
        int opcion = teclado.nextInt();
        
        if(opcion >6 || opcion <0){
            System.out.println("Debe escoger un valor entre 1 y 6");
            menu();
        }
       
        switch(opcion){
            case 1 : coche=crearVehiculo(); taller.insertaVehiculo(coche); menu(); break;
            case 2 : taller.listarVehiculos(); menu(); break;
            case 3 : buscaVehiculo(); menu(); break;
            case 4 : actualizaKms(); menu(); break;
            case 5 : eliminaVehiculo(); menu(); break;
            case 6 : System.exit(1);
        }
    }
    
    //pide por pantalla los datos necesarios para crear un objeto vehículo, lo instancia y los devuelve
    
    
        public Vehiculo crearVehiculo() {
         
            pideNombre();
        
            pideDNI();
        
            pideMatricula();
        
            System.out.println("Introduce la marca del coche");
        
            String marca=teclado.nextLine();
        
            System.out.println("Díganos la reparación a realizar en su coche");
        
            reparacion=teclado.nextLine();
        
            compruebaFecha();
        
            pideKilometros();
    	 
            coche=new Vehiculo(nombrePropietario, DNI, marca,kilometros,diaMatricula, mesMatricula, anioMatricula,reparacion, matricula);
        
       return coche;
   
    	
     }  
        
        
        //pide por pantalla el nombre, lo guarda en un atributo de clase y llama al método que hace la validación
        //si no es correcto, muestra un mensaje de error y vuelve pedir el dato
       
    
       private void pideNombre(){
       
            System.out.println("Introduce el nombre y apellidos del propietario");
         
            nombrePropietario=teclado.nextLine();
       
            if(!valida.validaNombre(nombrePropietario)){
           
            System.out.println("\nNombre no váLido. Por favor, vuelva a intentarlo\n");
           
            pideNombre();
       }
   }
       
       
       //pide por pantalla los kilometros del vehiculo y lo guarda en un atributo de clase
       //en caso de que el número introducido sea menor que cero, muestra un mensaje de error y vuelve a pedir el dato
       
        private void pideKilometros() {
        
            System.out.println("Introduce el número de kilómetros");
        
            kilometros=teclado.nextInt(); // lee los datos del teclado
        
            while(kilometros<0) { // sólo se ejecuta si el valor introducido por teclado es menor que cero
                              // en ese caso, muestra un mensaje de error y vuelve a llamar al método
                              
    		System.out.println("El número de kilómetros debe ser mayor que cero");
                
    		System.out.println("Por favor, vuelve a intentarlo");
                
    		pideKilometros();
                
    	}
        
    	
    }
        
        //pide por pantalla el año, mes y día de matriculación y los guarda en atributos de clase. 
        //Para hacer la validación, instancia un objeto LocalDate con los datos recogidos y comprueba que la fecha es anterior a la actual
        //en caso de introducir una fecha posterior a la actual, vuelve pedir los datos
           
        private void compruebaFecha() {
        
            System.out.println("Ahora necesitamos la fecha de matriculación. Introduzca el año");
        
            anioMatricula=teclado.nextInt(); 
        
            System.out.println("Introduzca el número de mes");
        
            mesMatricula=teclado.nextInt();
        
            System.out.println("Introduzca el día");
        
            diaMatricula=teclado.nextInt();
        
        //crea un objeto LocalDate con la fecha dada por teclado
        
            fecha = LocalDate.of(anioMatricula, mesMatricula, diaMatricula);
    	
    	//Comprueba que la fecha no es posterior a la fecha actual, en caso contrario, vuelve ejecutar el método
    	
            LocalDate fechaActual = LocalDate.now(); 
        
            if(ChronoUnit.DAYS.between(fecha, fechaActual )<0){
            
    		System.out.println("\n La fecha no es correcta. Por favor, inténtelo de nuevo \n");
                
    		compruebaFecha();
                
    	}
        
    }
        
        
      //Pide por pantalla el dato DNI y lo guarda en una variable de clase. Con el dato guardado, llama al método que lo valida
      // de la clase validaciones y en caso de no ser válido, muestra un mensaje de error y vuelve a pedir el dato
        
            
   private void pideDNI(){
       
            System.out.println("\nIntroduzca su DNI\n");
       
             DNI = teclado.nextLine();
       
             if (!valida.validaDNI(DNI)) {
                 
                System.out.println("\nDNI no válido. Por favor, vuelva a intentarlo\n");
                
           pideDNI();
           
       } 
   }
   
   
   //Pide por pantalla el dato Matricula y lo guarda en una variable de clase. Con el dato guardado, llama al método que lo valida
   // de la clase validaciones y en caso de no ser válido, ,uestra un mensaje de error y vuelve a pedir el dato
   
   private void pideMatricula(){
       
        System.out.println("\nPor favor, teclee la matrícula del coche\n");
        
    	matricula=teclado.nextLine();
        
        if(!valida.validaMatricula(matricula)){
            
            System.out.println("\nMatrícula no válida. Por favor, buelva a intentarlo\n");
            
            pideMatricula();
            
        }
   }
   
   
   //pide por pantalla la matrícula y los kilométros a modificar llamando a los métodos que se encargan de hacer ese trabajo, 
   //guarda los datos en variables de clase y llama a el método de la clase TallerSamuel que actualiza los Kms. En caso de que la matrícula
   //leída por teclado no exista en el array de objetos, muestra un mensaje de error
    
   private void actualizaKms(){
       pideMatricula();
       pideKilometros();
       if(taller.actualizaKms(matricula, kilometros)) System.out.println("\nKilómetros actualizados correctamente");
       else System.out.println("\nLa matrícula seleccionada no existe");
   }
   
   //pide por pantalla una matrícula con el método pideMatricula() y llama al método de la clase TallerSamuel que muestra los datos del
   //vehículo que corresponde con la matrícula seleccionada. LLeva un try catch porque el método de la clase TallerSamuel devuelve null en caso 
   //de que la matricúla no corresponda con ningún objeto del array. En ese caso, muestra un mensaje de error
   
   private void buscaVehiculo(){
       pideMatricula();
       try{
       if(taller.buscaVehiculo(matricula)==null) System.out.println("\nLa matrícula buscada no existe");
       else System.out.println(taller.buscaVehiculo(matricula));
       }catch (Exception e){ System.out.println("\nLa matrícula buscada no existe");}
   }
   
   //pide por pantalla una matrícula y llama al método que comprueba si esa matrícula existe
   // devuelve un mensaje si ha eliminado el objeto correctamente o si no lo ha encontrado
   
   public void eliminaVehiculo(){
       
       pideMatricula();
       
       if(taller.eliminaVehiculo(matricula)) System.out.println("\nVehículo borrado correctamente");
       else System.out.println("\nVehículo no encontrado\n");
       
   }
   
   
   // atributos necesarios para crear un objeto de tipo Vehiculo
   
   private int anioMatricula;
   
   private int mesMatricula;
   
   private int diaMatricula;
   
   private LocalDate fecha;
           
   private int kilometros;
   
   private String DNI;
   
   private String matricula;
   
   private String reparacion;
   
   private String nombrePropietario;
   
   // objeto que lee los datos introducidos por teclado
   
   private Scanner teclado = new Scanner(System.in);
   
   //objeto para llamar a los métodos que hacen las validaciones
   
   private Validaciones valida = new Validaciones();
   
   //objeto vehículo para crear una instancia
   
   private Vehiculo coche;
   
   //objeto TallerSamuel para llamar a los métodos de esa clase
   
   private TallerSamuel taller = new TallerSamuel();
    
}
